using System;
using System.Windows.Forms;
using WinForms.TH4c;
using WinForms.TH4d;

namespace WinForms;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        Application.Run(new FrmPhepTinh());
    }
}
