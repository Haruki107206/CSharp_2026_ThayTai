#nullable enable
namespace WinForms.TH4c;

partial class FrmUclnBcnn
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, lblA = null!, lblB = null!, lblUCLN = null!, lblBCNN = null!;
    private System.Windows.Forms.TextBox txtA = null!, txtB = null!, txtUCLN = null!, txtBCNN = null!;
    private System.Windows.Forms.Button btnThucHien = null!, btnTiepTuc = null!, btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        lblA = new System.Windows.Forms.Label();
        lblB = new System.Windows.Forms.Label();
        lblUCLN = new System.Windows.Forms.Label();
        lblBCNN = new System.Windows.Forms.Label();
        txtA = new System.Windows.Forms.TextBox();
        txtB = new System.Windows.Forms.TextBox();
        txtUCLN = new System.Windows.Forms.TextBox();
        txtBCNN = new System.Windows.Forms.TextBox();
        btnThucHien = new System.Windows.Forms.Button();
        btnTiepTuc = new System.Windows.Forms.Button();
        btnThoat = new System.Windows.Forms.Button();
        SuspendLayout();

        Name = "FrmUclnBcnn";
        Text = "Ước Số - Bội Số";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(400, 280);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "ƯỚC SỐ CHUNG - BỘI SỐ CHUNG";
        title.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.Red;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(25, 18);
        title.Size = new System.Drawing.Size(350, 30);

        lblA.Text = "Nhập số a :";
        lblA.AutoSize = true;
        lblA.Location = new System.Drawing.Point(38, 74);
        txtA.Location = new System.Drawing.Point(145, 70);
        txtA.Size = new System.Drawing.Size(145, 24);
        txtA.Name = "txtA";

        lblB.Text = "Nhập số b :";
        lblB.AutoSize = true;
        lblB.Location = new System.Drawing.Point(38, 114);
        txtB.Location = new System.Drawing.Point(145, 110);
        txtB.Size = new System.Drawing.Size(145, 24);
        txtB.Name = "txtB";

        lblUCLN.Text = "Ước số chung lớn nhất :";
        lblUCLN.AutoSize = true;
        lblUCLN.Location = new System.Drawing.Point(38, 154);
        txtUCLN.Location = new System.Drawing.Point(255, 150);
        txtUCLN.Size = new System.Drawing.Size(65, 24);
        txtUCLN.Name = "txtUCLN";
        txtUCLN.ReadOnly = true;

        lblBCNN.Text = "Bội số chung nhỏ nhất :";
        lblBCNN.AutoSize = true;
        lblBCNN.Location = new System.Drawing.Point(38, 194);
        txtBCNN.Location = new System.Drawing.Point(255, 190);
        txtBCNN.Size = new System.Drawing.Size(65, 24);
        txtBCNN.Name = "txtBCNN";
        txtBCNN.ReadOnly = true;

        btnThucHien.Text = "Thực Hiện";
        btnThucHien.Location = new System.Drawing.Point(20, 230);
        btnThucHien.Size = new System.Drawing.Size(115, 35);
        btnThucHien.Click += btnThucHien_Click;

        btnTiepTuc.Text = "Tiếp Tục";
        btnTiepTuc.Location = new System.Drawing.Point(145, 230);
        btnTiepTuc.Size = new System.Drawing.Size(105, 35);
        btnTiepTuc.Click += btnTiepTuc_Click;

        btnThoat.Text = "Thoát";
        btnThoat.Location = new System.Drawing.Point(270, 230);
        btnThoat.Size = new System.Drawing.Size(105, 35);
        btnThoat.Click += btnThoat_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, lblA, txtA, lblB, txtB, lblUCLN, txtUCLN,
            lblBCNN, txtBCNN, btnThucHien, btnTiepTuc, btnThoat
        });
        FormClosing += Form_FormClosing;
        ResumeLayout(false);
        PerformLayout();
    }
}
