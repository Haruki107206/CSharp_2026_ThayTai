#nullable enable
namespace WinForms.TH4c;

partial class FrmRapChieuPhim
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label lblManHinh = null!, lblThanhTienText = null!, lblThanhTien = null!, lblChuThich = null!;
    private System.Windows.Forms.Button btnChon = null!, btnHuy = null!, btnKetThuc = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblManHinh = new System.Windows.Forms.Label();
        lblThanhTienText = new System.Windows.Forms.Label();
        lblThanhTien = new System.Windows.Forms.Label();
        lblChuThich = new System.Windows.Forms.Label();
        btnChon = new System.Windows.Forms.Button();
        btnHuy = new System.Windows.Forms.Button();
        btnKetThuc = new System.Windows.Forms.Button();
        SuspendLayout();

        Name = "FrmRapChieuPhim";
        Text = "BÁN VÉ RẠP CHIẾU BÓNG";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(370, 335);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        lblManHinh.Text = "MÀN ẢNH";
        lblManHinh.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
        lblManHinh.ForeColor = System.Drawing.Color.DarkOrange;
        lblManHinh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        lblManHinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        lblManHinh.Location = new System.Drawing.Point(15, 12);
        lblManHinh.Size = new System.Drawing.Size(315, 38);

        // Chú thích có trong dữ liệu cũ nhưng ẩn để khớp giao diện trong PDF.
        lblChuThich.Text = "";
        lblChuThich.Visible = false;

        lblThanhTienText.Text = "Thành Tiền:";
        lblThanhTienText.AutoSize = true;
        lblThanhTienText.Location = new System.Drawing.Point(22, 232);

        lblThanhTien.Text = "0";
        lblThanhTien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        lblThanhTien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        lblThanhTien.Location = new System.Drawing.Point(145, 228);
        lblThanhTien.Size = new System.Drawing.Size(125, 28);

        btnChon.Text = "Chọn";
        btnChon.Location = new System.Drawing.Point(28, 275);
        btnChon.Size = new System.Drawing.Size(90, 32);
        btnChon.Click += btnChon_Click;

        btnHuy.Text = "Hủy bỏ";
        btnHuy.Location = new System.Drawing.Point(130, 275);
        btnHuy.Size = new System.Drawing.Size(90, 32);
        btnHuy.Click += btnHuy_Click;

        btnKetThuc.Text = "Kết thúc";
        btnKetThuc.Location = new System.Drawing.Point(232, 275);
        btnKetThuc.Size = new System.Drawing.Size(100, 32);
        btnKetThuc.Click += btnKetThuc_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lblManHinh, lblChuThich, lblThanhTienText, lblThanhTien,
            btnChon, btnHuy, btnKetThuc
        });
        FormClosing += Form_FormClosing;
        ResumeLayout(false);
        PerformLayout();
    }
}
