#nullable enable
namespace WinForms.TH4c;

partial class FrmDangKyTaiKhoan
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label lblTieuDe = null!, lblTaiKhoan = null!, lblEmail = null!, lblMatKhau = null!, lblXacNhan = null!;
    private System.Windows.Forms.Label lblSao1 = null!, lblSao2 = null!, lblSao3 = null!;
    private System.Windows.Forms.TextBox txtTaiKhoan = null!, txtEmail = null!, txtMatKhau = null!, txtXacNhan = null!;
    private System.Windows.Forms.Button btnDangKy = null!;
    private System.Windows.Forms.ErrorProvider errorProvider1 = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTieuDe = new System.Windows.Forms.Label();
        lblTaiKhoan = new System.Windows.Forms.Label();
        lblEmail = new System.Windows.Forms.Label();
        lblMatKhau = new System.Windows.Forms.Label();
        lblXacNhan = new System.Windows.Forms.Label();
        lblSao1 = new System.Windows.Forms.Label();
        lblSao2 = new System.Windows.Forms.Label();
        lblSao3 = new System.Windows.Forms.Label();
        txtTaiKhoan = new System.Windows.Forms.TextBox();
        txtEmail = new System.Windows.Forms.TextBox();
        txtMatKhau = new System.Windows.Forms.TextBox();
        txtXacNhan = new System.Windows.Forms.TextBox();
        btnDangKy = new System.Windows.Forms.Button();
        errorProvider1 = new System.Windows.Forms.ErrorProvider(components);
        ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
        SuspendLayout();

        Name = "FrmDangKyTaiKhoan";
        Text = "Đăng ký tài khoản";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(560, 330);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        lblTieuDe.Text = "Đăng ký tài khoản";
        lblTieuDe.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
        lblTieuDe.ForeColor = System.Drawing.Color.DodgerBlue;
        lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        lblTieuDe.Location = new System.Drawing.Point(135, 18);
        lblTieuDe.Size = new System.Drawing.Size(180, 28);

        lblTaiKhoan.Text = "Tên đăng nhập";
        lblTaiKhoan.AutoSize = true;
        lblTaiKhoan.Location = new System.Drawing.Point(28, 70);
        txtTaiKhoan.Name = "txtTaiKhoan";
        txtTaiKhoan.Location = new System.Drawing.Point(215, 66);
        txtTaiKhoan.Size = new System.Drawing.Size(185, 24);

        lblEmail.Text = "Địa chỉ email";
        lblEmail.AutoSize = true;
        lblEmail.Location = new System.Drawing.Point(28, 102);
        txtEmail.Name = "txtEmail";
        txtEmail.Location = new System.Drawing.Point(215, 98);
        txtEmail.Size = new System.Drawing.Size(185, 24);

        lblMatKhau.Text = "Mật khẩu";
        lblMatKhau.AutoSize = true;
        lblMatKhau.Location = new System.Drawing.Point(28, 134);
        txtMatKhau.Name = "txtMatKhau";
        txtMatKhau.Location = new System.Drawing.Point(215, 130);
        txtMatKhau.Size = new System.Drawing.Size(185, 24);
        txtMatKhau.PasswordChar = '*';

        lblXacNhan.Text = "Xác nhận mật khẩu";
        lblXacNhan.AutoSize = true;
        lblXacNhan.Location = new System.Drawing.Point(28, 166);
        txtXacNhan.Name = "txtXacNhan";
        txtXacNhan.Location = new System.Drawing.Point(215, 162);
        txtXacNhan.Size = new System.Drawing.Size(185, 24);
        txtXacNhan.PasswordChar = '*';

        lblSao1.Text = "(*)";
        lblSao1.ForeColor = System.Drawing.Color.Red;
        lblSao1.AutoSize = true;
        lblSao1.Location = new System.Drawing.Point(402, 70);

        lblSao2.Text = "(*)";
        lblSao2.ForeColor = System.Drawing.Color.Red;
        lblSao2.AutoSize = true;
        lblSao2.Location = new System.Drawing.Point(402, 102);

        lblSao3.Text = "(*)";
        lblSao3.ForeColor = System.Drawing.Color.Red;
        lblSao3.AutoSize = true;
        lblSao3.Location = new System.Drawing.Point(402, 134);

        btnDangKy.Text = "Đăng ký";
        btnDangKy.Location = new System.Drawing.Point(150, 208);
        btnDangKy.Size = new System.Drawing.Size(130, 38);
        btnDangKy.Click += btnDangKy_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lblTieuDe, lblTaiKhoan, txtTaiKhoan, lblEmail, txtEmail,
            lblMatKhau, txtMatKhau, lblXacNhan, txtXacNhan,
            lblSao1, lblSao2, lblSao3, btnDangKy
        });
        FormClosing += FrmDangKyTaiKhoan_FormClosing;
        ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
}
