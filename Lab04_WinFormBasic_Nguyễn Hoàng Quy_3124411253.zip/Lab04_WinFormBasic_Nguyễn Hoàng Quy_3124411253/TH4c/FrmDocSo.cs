using System;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmDocSo : Form
{
    private readonly string[] _so = { "", "Một", "Hai", "Ba", "Bốn", "Năm", "Sáu", "Bảy", "Tám", "Chín" };

    public FrmDocSo()
    {
        InitializeComponent();
        txtSo.KeyPress += NumberKeyPress;
    }

    private static void NumberKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            e.Handled = true;
    }

    private string DocHaiChuSo(int n)
    {
        if (n < 10) return _so[n];
        if (n == 10) return "Mười";
        if (n < 20)
            return "Mười " + (n == 15 ? "Lăm" : _so[n - 10]);

        int chuc = n / 10;
        int donVi = n % 10;
        string ketQua = _so[chuc] + " Mươi";

        if (donVi == 0) return ketQua;
        if (donVi == 1) return ketQua + " Mốt";
        if (donVi == 5) return ketQua + " Lăm";
        return ketQua + " " + _so[donVi];
    }

    private string DocSo(int n)
    {
        if (n < 10) return _so[n];
        if (n < 100) return DocHaiChuSo(n);

        int tram = n / 100;
        int du = n % 100;
        string ketQua = _so[tram] + " Trăm";

        if (du == 0) return ketQua;
        if (du < 10) return ketQua + " Lẻ " + _so[du];
        return ketQua + " " + DocHaiChuSo(du);
    }

    private void btnThucHien_Click(object? sender, EventArgs e)
    {
        if (!int.TryParse(txtSo.Text, out int n) || n < 1 || n > 999)
        {
            MessageBox.Show("Hãy nhập số nguyên dương từ 1 đến 999.");
            txtSo.Focus();
            return;
        }

        txtKetQua.Text = DocSo(n);
    }

    private void btnXoa_Click(object? sender, EventArgs e)
    {
        txtSo.Clear(); txtKetQua.Clear(); txtSo.Focus();
    }

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
