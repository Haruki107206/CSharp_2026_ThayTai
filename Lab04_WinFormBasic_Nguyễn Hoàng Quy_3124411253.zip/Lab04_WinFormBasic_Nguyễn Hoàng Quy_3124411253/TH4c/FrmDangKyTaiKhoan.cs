using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmDangKyTaiKhoan : Form
{
    public FrmDangKyTaiKhoan()
    {
        InitializeComponent();
        AcceptButton = btnDangKy;
        txtEmail.Leave += txtEmail_Leave;
        txtTaiKhoan.Leave += Required_Leave;
        txtMatKhau.Leave += Required_Leave;
    }

    private void Required_Leave(object? sender, EventArgs e)
    {
        if (sender is TextBox txt)
            errorProvider1.SetError(txt,
                string.IsNullOrWhiteSpace(txt.Text) ? "Bắt buộc nhập." : "");
    }

    private void txtEmail_Leave(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtEmail.Text))
        {
            errorProvider1.SetError(txtEmail, "Bắt buộc nhập.");
            return;
        }

        bool ok = Regex.IsMatch(
            txtEmail.Text.Trim(),
            @"^[^\s@]+@[^\s@]+\.[^\s@]+$");

        errorProvider1.SetError(txtEmail,
            ok ? "" : "Email không đúng định dạng.");
    }

    private bool KiemTraDuLieu()
    {
        Required_Leave(txtTaiKhoan, EventArgs.Empty);
        Required_Leave(txtMatKhau, EventArgs.Empty);
        txtEmail_Leave(txtEmail, EventArgs.Empty);

        if (string.IsNullOrWhiteSpace(txtTaiKhoan.Text) ||
            string.IsNullOrWhiteSpace(txtEmail.Text) ||
            string.IsNullOrWhiteSpace(txtMatKhau.Text))
            return false;

        if (txtMatKhau.Text != txtXacNhan.Text)
        {
            errorProvider1.SetError(txtXacNhan, "Mật khẩu xác nhận không khớp.");
            return false;
        }

        errorProvider1.Clear();
        return true;
    }

    private void btnDangKy_Click(object? sender, EventArgs e)
    {
        if (!KiemTraDuLieu())
        {
            MessageBox.Show("Vui lòng kiểm tra lại dữ liệu.");
            return;
        }

        string s = "Tên đăng nhập: " + txtTaiKhoan.Text + "\n" +
                   "Email: " + txtEmail.Text + "\n" +
                   "Mật khẩu: " + txtMatKhau.Text + "\n" +
                   "Xác nhận mật khẩu: " + txtXacNhan.Text;

        MessageBox.Show(s, "Thông tin đăng ký");
    }

    private void FrmDangKyTaiKhoan_FormClosing(object? sender, FormClosingEventArgs e)
    {
        DialogResult r = MessageBox.Show(
            "Bạn có muốn thoát?", "Xác nhận",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (r == DialogResult.No)
            e.Cancel = true;
    }
}
