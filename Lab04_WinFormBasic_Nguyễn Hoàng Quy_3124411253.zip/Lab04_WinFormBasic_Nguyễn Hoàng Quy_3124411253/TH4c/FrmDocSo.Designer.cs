#nullable enable
namespace WinForms.TH4c;

partial class FrmDocSo
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, lblNhap = null!, lblKetQua = null!;
    private System.Windows.Forms.TextBox txtSo = null!, txtKetQua = null!;
    private System.Windows.Forms.Button btnThucHien = null!, btnXoa = null!, btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        lblNhap = new System.Windows.Forms.Label();
        lblKetQua = new System.Windows.Forms.Label();
        txtSo = new System.Windows.Forms.TextBox();
        txtKetQua = new System.Windows.Forms.TextBox();
        btnThucHien = new System.Windows.Forms.Button();
        btnXoa = new System.Windows.Forms.Button();
        btnThoat = new System.Windows.Forms.Button();
        SuspendLayout();

        Name = "FrmDocSo";
        Text = "Tâm Gà - Đọc Chữ Số";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(470, 265);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "Đọc Số Thành Chữ";
        title.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.Red;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(45, 16);
        title.Size = new System.Drawing.Size(350, 51);

        lblNhap.Text = "Nhập dãy số : ( từ 1 đến 999 )";
        lblNhap.AutoSize = true;
        lblNhap.Location = new System.Drawing.Point(28, 67);
        txtSo.Name = "txtSo";
        txtSo.Location = new System.Drawing.Point(315, 63);
        txtSo.Size = new System.Drawing.Size(58, 24);

        btnThucHien.Text = "Thực hiện";
        btnThucHien.Location = new System.Drawing.Point(28, 103);
        btnThucHien.Size = new System.Drawing.Size(90, 34);
        btnThucHien.Click += btnThucHien_Click;

        btnXoa.Text = "Xóa";
        btnXoa.Location = new System.Drawing.Point(135, 103);
        btnXoa.Size = new System.Drawing.Size(90, 34);
        btnXoa.Click += btnXoa_Click;

        btnThoat.Text = "Thoát";
        btnThoat.Location = new System.Drawing.Point(242, 103);
        btnThoat.Size = new System.Drawing.Size(90, 34);
        btnThoat.Click += btnThoat_Click;

        txtKetQua.Name = "txtKetQua";
        txtKetQua.Location = new System.Drawing.Point(28, 150);
        txtKetQua.Size = new System.Drawing.Size(304, 24);
        txtKetQua.ReadOnly = true;
        txtKetQua.BackColor = System.Drawing.Color.MistyRose;
        txtKetQua.ForeColor = System.Drawing.Color.Blue;

        lblKetQua.Text = "";
        lblKetQua.Location = new System.Drawing.Point(0, 0);
        lblKetQua.Size = new System.Drawing.Size(0, 0);

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, lblNhap, txtSo, btnThucHien, btnXoa, btnThoat, txtKetQua
        });
        FormClosing += Form_FormClosing;
        ResumeLayout(false);
        PerformLayout();
    }
}
