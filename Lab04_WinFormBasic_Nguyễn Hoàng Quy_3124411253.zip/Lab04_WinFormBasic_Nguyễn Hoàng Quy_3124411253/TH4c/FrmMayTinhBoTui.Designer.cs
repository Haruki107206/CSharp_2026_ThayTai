#nullable enable
namespace WinForms.TH4c;

partial class FrmMayTinhBoTui
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!;
    private System.Windows.Forms.TextBox txtManHinh = null!;
    private System.Windows.Forms.Button btn0 = null!, btn1 = null!, btn2 = null!, btn3 = null!, btn4 = null!, btn5 = null!, btn6 = null!, btn7 = null!, btn8 = null!, btn9 = null!;
    private System.Windows.Forms.Button btnBang = null!, btnC = null!, btnCong = null!, btnTru = null!, btnNhan = null!, btnChia = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        txtManHinh = new System.Windows.Forms.TextBox();
        btn0 = new System.Windows.Forms.Button(); btn1 = new System.Windows.Forms.Button(); btn2 = new System.Windows.Forms.Button(); btn3 = new System.Windows.Forms.Button();
        btn4 = new System.Windows.Forms.Button(); btn5 = new System.Windows.Forms.Button(); btn6 = new System.Windows.Forms.Button(); btn7 = new System.Windows.Forms.Button(); btn8 = new System.Windows.Forms.Button(); btn9 = new System.Windows.Forms.Button();
        btnBang = new System.Windows.Forms.Button(); btnC = new System.Windows.Forms.Button(); btnCong = new System.Windows.Forms.Button(); btnTru = new System.Windows.Forms.Button(); btnNhan = new System.Windows.Forms.Button(); btnChia = new System.Windows.Forms.Button();
        SuspendLayout();

        Name = "FrmMayTinhBoTui";
        Text = "Máy Tính Bỏ Túi";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(335, 375);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "Máy Tính Bỏ Túi";
        title.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.Red;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(15, 15);
        title.Size = new System.Drawing.Size(335, 50);

        txtManHinh.Name = "txtManHinh";
        txtManHinh.Location = new System.Drawing.Point(25, 72);
        txtManHinh.Size = new System.Drawing.Size(275, 28);
        txtManHinh.ReadOnly = true;
        txtManHinh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
        txtManHinh.Font = new System.Drawing.Font("Tahoma", 12F);

        TaoNut(btn1, "1", 30, 115);
        TaoNut(btn2, "2", 95, 115);
        TaoNut(btn3, "3", 160, 115);
        TaoNut(btn4, "4", 225, 115);

        TaoNut(btn5, "5", 30, 163);
        TaoNut(btn6, "6", 95, 163);
        TaoNut(btn7, "7", 160, 163);
        TaoNut(btn8, "8", 225, 163);

        TaoNut(btn9, "9", 30, 211);
        TaoNut(btn0, "0", 95, 211);
        TaoNut(btnBang, "=", 160, 211);
        TaoNut(btnC, "C", 225, 211);

        TaoNut(btnCong, "+", 30, 259);
        TaoNut(btnTru, "-", 95, 259);
        TaoNut(btnNhan, "*", 160, 259);
        TaoNut(btnChia, "/", 225, 259);

        btn0.Click += So_Click; btn1.Click += So_Click; btn2.Click += So_Click; btn3.Click += So_Click; btn4.Click += So_Click;
        btn5.Click += So_Click; btn6.Click += So_Click; btn7.Click += So_Click; btn8.Click += So_Click; btn9.Click += So_Click;
        btnCong.Click += Dau_Click; btnTru.Click += Dau_Click; btnNhan.Click += Dau_Click; btnChia.Click += Dau_Click;
        btnBang.Click += btnBang_Click; btnC.Click += btnC_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, txtManHinh,
            btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8,
            btn9, btn0, btnBang, btnC, btnCong, btnTru, btnNhan, btnChia
        });
        FormClosing += Form_FormClosing;
        ResumeLayout(false);
        PerformLayout();
    }

    private static void TaoNut(System.Windows.Forms.Button btn, string text, int x, int y)
    {
        btn.Text = text;
        btn.Location = new System.Drawing.Point(x, y);
        btn.Size = new System.Drawing.Size(50, 38);
        btn.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
    }
}
