using System;
using System.Globalization;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmMayTinhBoTui : Form
{
    private double _soThuNhat;
    private string _phepToan = "";
    private bool _nhapMoi = true;

    public FrmMayTinhBoTui() => InitializeComponent();

    private void So_Click(object? sender, EventArgs e)
    {
        Button btn = (Button)sender!;

        if (_nhapMoi)
        {
            txtManHinh.Clear();
            _nhapMoi = false;
        }

        txtManHinh.Text += btn.Text;
    }

    private void Dau_Click(object? sender, EventArgs e)
    {
        if (!double.TryParse(txtManHinh.Text, out _soThuNhat))
        {
            MessageBox.Show("Giá trị không hợp lệ.");
            return;
        }

        _phepToan = ((Button)sender!).Text;
        _nhapMoi = true;
    }

    private void btnBang_Click(object? sender, EventArgs e)
    {
        if (!double.TryParse(txtManHinh.Text, out double soThuHai) || _phepToan == "")
            return;

        double ketQua;

        switch (_phepToan)
        {
            case "+": ketQua = _soThuNhat + soThuHai; break;
            case "-": ketQua = _soThuNhat - soThuHai; break;
            case "x":
            case "*": ketQua = _soThuNhat * soThuHai; break;
            default:
                if (soThuHai == 0)
                {
                    MessageBox.Show("Không thể chia cho 0.");
                    return;
                }
                ketQua = _soThuNhat / soThuHai;
                break;
        }

        txtManHinh.Text = ketQua.ToString(CultureInfo.InvariantCulture);
        _phepToan = "";
        _nhapMoi = true;
    }

    private void btnC_Click(object? sender, EventArgs e)
    {
        txtManHinh.Clear();
        _soThuNhat = 0;
        _phepToan = "";
        _nhapMoi = true;
    }

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
