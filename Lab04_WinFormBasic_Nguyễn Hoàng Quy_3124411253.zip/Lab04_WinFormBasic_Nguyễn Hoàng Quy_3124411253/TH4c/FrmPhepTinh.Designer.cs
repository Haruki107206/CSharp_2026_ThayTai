#nullable enable
namespace WinForms.TH4c;

partial class FrmPhepTinh
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label lblTieuDe = null!, lblA = null!, lblB = null!, lblKetQua = null!;
    private System.Windows.Forms.TextBox txtA = null!, txtB = null!, txtKetQua = null!;
    private System.Windows.Forms.Button btnCong = null!, btnTru = null!, btnNhan = null!, btnChia = null!;
    private System.Windows.Forms.ErrorProvider errorProvider1 = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTieuDe = new System.Windows.Forms.Label();
        lblA = new System.Windows.Forms.Label();
        lblB = new System.Windows.Forms.Label();
        lblKetQua = new System.Windows.Forms.Label();
        txtA = new System.Windows.Forms.TextBox();
        txtB = new System.Windows.Forms.TextBox();
        txtKetQua = new System.Windows.Forms.TextBox();
        btnCong = new System.Windows.Forms.Button();
        btnTru = new System.Windows.Forms.Button();
        btnNhan = new System.Windows.Forms.Button();
        btnChia = new System.Windows.Forms.Button();
        errorProvider1 = new System.Windows.Forms.ErrorProvider(components);
        ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
        SuspendLayout();

        Name = "FrmPhepTinh";
        Text = "Cộng trừ nhân chia";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(450, 220);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        lblTieuDe.Text = "CỘNG TRỪ NHÂN CHIA";
        lblTieuDe.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold);
        lblTieuDe.ForeColor = System.Drawing.Color.RoyalBlue;
        lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        lblTieuDe.Location = new System.Drawing.Point(125, 15);
        lblTieuDe.Size = new System.Drawing.Size(200, 28);

        lblA.Text = "a =";
        lblA.AutoSize = true;
        lblA.Location = new System.Drawing.Point(35, 63);
        txtA.Name = "txtA";
        txtA.Location = new System.Drawing.Point(75, 59);
        txtA.Size = new System.Drawing.Size(115, 24);
        txtA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

        lblB.Text = "b =";
        lblB.AutoSize = true;
        lblB.Location = new System.Drawing.Point(245, 63);
        txtB.Name = "txtB";
        txtB.Location = new System.Drawing.Point(285, 59);
        txtB.Size = new System.Drawing.Size(115, 24);
        txtB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

        lblKetQua.Text = "Kết quả";
        lblKetQua.AutoSize = true;
        lblKetQua.Location = new System.Drawing.Point(15, 101);
        txtKetQua.Name = "txtKetQua";
        txtKetQua.Location = new System.Drawing.Point(95, 97);
        txtKetQua.Size = new System.Drawing.Size(305, 24);
        txtKetQua.ReadOnly = true;
        txtKetQua.BackColor = System.Drawing.Color.White;
        txtKetQua.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

        btnCong.Text = "+";
        btnCong.Location = new System.Drawing.Point(45, 145);
        btnCong.Size = new System.Drawing.Size(75, 35);
        btnCong.Click += btnCong_Click;

        btnTru.Text = "-";
        btnTru.Location = new System.Drawing.Point(135, 145);
        btnTru.Size = new System.Drawing.Size(75, 35);
        btnTru.Click += btnTru_Click;

        btnNhan.Text = "x";
        btnNhan.Location = new System.Drawing.Point(225, 145);
        btnNhan.Size = new System.Drawing.Size(75, 35);
        btnNhan.Click += btnNhan_Click;

        btnChia.Text = "/";
        btnChia.Location = new System.Drawing.Point(315, 145);
        btnChia.Size = new System.Drawing.Size(75, 35);
        btnChia.Click += btnChia_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lblTieuDe, lblA, txtA, lblB, txtB,
            lblKetQua, txtKetQua, btnCong, btnTru, btnNhan, btnChia
        });
        FormClosing += FrmPhepTinh_FormClosing;
        ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
}
