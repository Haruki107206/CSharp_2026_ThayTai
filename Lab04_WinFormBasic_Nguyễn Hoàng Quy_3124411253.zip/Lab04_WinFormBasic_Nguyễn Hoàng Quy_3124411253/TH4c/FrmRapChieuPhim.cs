using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmRapChieuPhim : Form
{
    private readonly Button[] _ghe = new Button[15];
    private readonly bool[] _daBan = new bool[15];
    private readonly bool[] _dangChon = new bool[15];

    public FrmRapChieuPhim()
    {
        InitializeComponent();
        TaoGhe();
    }

    private void TaoGhe()
    {
        for (int i = 0; i < 15; i++)
        {
            Button btn = new Button
            {
                Text = (i + 1).ToString(),
                Tag = i,
                Size = new Size(55, 40),
                BackColor = Color.White,
                Font = new Font("Tahoma", 10F, FontStyle.Bold)
            };

            btn.Location = new Point(20 + (i % 5) * 62, 72 + (i / 5) * 47);
            btn.Click += Ghe_Click;
            _ghe[i] = btn;
            Controls.Add(btn);
        }

        // Trạng thái mẫu như hình trong tài liệu: vàng = đã bán, xanh = đang chọn.
        foreach (int seat in new[] { 2, 7, 9, 11 })
        {
            _daBan[seat - 1] = true;
            _ghe[seat - 1].BackColor = Color.Yellow;
        }

        foreach (int seat in new[] { 1, 12, 13, 14 })
        {
            _dangChon[seat - 1] = true;
            _ghe[seat - 1].BackColor = Color.Blue;
            _ghe[seat - 1].ForeColor = Color.White;
        }
    }

    private static int GiaVe(int index)
    {
        if (index < 5) return 1000;
        if (index < 10) return 1500;
        return 2000;
    }

    private void Ghe_Click(object? sender, EventArgs e)
    {
        Button btn = (Button)sender!;
        int index = (int)btn.Tag!;

        if (_daBan[index])
        {
            MessageBox.Show("Vị trí này đã bán vé.");
            return;
        }

        _dangChon[index] = !_dangChon[index];
        btn.BackColor = _dangChon[index] ? Color.Blue : Color.White;
        btn.ForeColor = _dangChon[index] ? Color.White : Color.Black;
    }

    private void btnChon_Click(object? sender, EventArgs e)
    {
        int thanhTien = 0;

        for (int i = 0; i < 15; i++)
        {
            if (_dangChon[i])
            {
                _daBan[i] = true;
                _dangChon[i] = false;
                _ghe[i].BackColor = Color.Yellow;
                _ghe[i].ForeColor = Color.Black;
                thanhTien += GiaVe(i);
            }
        }

        lblThanhTien.Text = thanhTien.ToString("N0") + " đ";
    }

    private void btnHuy_Click(object? sender, EventArgs e)
    {
        for (int i = 0; i < 15; i++)
        {
            if (_dangChon[i])
            {
                _dangChon[i] = false;
                _ghe[i].BackColor = Color.White;
                _ghe[i].ForeColor = Color.Black;
            }
        }

        lblThanhTien.Text = "0 đ";
    }

    private void btnKetThuc_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
