#nullable enable
namespace WinForms.TH4c;

partial class FrmDaySo
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, l1 = null!, l2 = null!, l3 = null!, l4 = null!, l5 = null!;
    private System.Windows.Forms.TextBox txtNhapSo = null!, txtDayVuaNhap = null!, txtTong = null!, txtTongChan = null!, txtTongLe = null!;
    private System.Windows.Forms.Button btnNhap = null!, btnTong = null!, btnTongChan = null!, btnTongLe = null!, btnTiepTuc = null!, btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        l1 = new System.Windows.Forms.Label();
        l2 = new System.Windows.Forms.Label();
        l3 = new System.Windows.Forms.Label();
        l4 = new System.Windows.Forms.Label();
        l5 = new System.Windows.Forms.Label();
        txtNhapSo = new System.Windows.Forms.TextBox();
        txtDayVuaNhap = new System.Windows.Forms.TextBox();
        txtTong = new System.Windows.Forms.TextBox();
        txtTongChan = new System.Windows.Forms.TextBox();
        txtTongLe = new System.Windows.Forms.TextBox();
        btnNhap = new System.Windows.Forms.Button();
        btnTong = new System.Windows.Forms.Button();
        btnTongChan = new System.Windows.Forms.Button();
        btnTongLe = new System.Windows.Forms.Button();
        btnTiepTuc = new System.Windows.Forms.Button();
        btnThoat = new System.Windows.Forms.Button();
        SuspendLayout();

        Name = "FrmDaySo";
        Text = "Dãy số và Tính Tổng";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(530, 330);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        l1.Text = "Nhập số :";
        l1.AutoSize = true;
        l1.Location = new System.Drawing.Point(32, 68);
        txtNhapSo.Name = "txtNhapSo";
        txtNhapSo.Location = new System.Drawing.Point(130, 64);
        txtNhapSo.Size = new System.Drawing.Size(100, 24);
        btnNhap.Text = "Nhập";
        btnNhap.Location = new System.Drawing.Point(245, 61);
        btnNhap.Size = new System.Drawing.Size(80, 30);
        btnNhap.Click += btnNhap_Click;

        l2.Text = "Dãy vừa nhập :";
        l2.AutoSize = true;
        l2.Location = new System.Drawing.Point(32, 106);
        txtDayVuaNhap.Name = "txtDayVuaNhap";
        txtDayVuaNhap.Location = new System.Drawing.Point(185, 102);
        txtDayVuaNhap.Size = new System.Drawing.Size(255, 24);
        txtDayVuaNhap.ReadOnly = true;

        l3.Text = "Tổng các phần tử trong dãy:";
        l3.AutoSize = true;
        l3.Location = new System.Drawing.Point(32, 144);
        txtTong.Name = "txtTong";
        txtTong.Location = new System.Drawing.Point(290, 140);
        txtTong.Size = new System.Drawing.Size(55, 24);
        txtTong.ReadOnly = true;

        l4.Text = "Tổng Chẵn:";
        l4.AutoSize = true;
        l4.Location = new System.Drawing.Point(32, 184);
        txtTongChan.Name = "txtTongChan";
        txtTongChan.Location = new System.Drawing.Point(145, 180);
        txtTongChan.Size = new System.Drawing.Size(75, 24);
        txtTongChan.ReadOnly = true;

        l5.Text = "Tổng Lẻ:";
        l5.AutoSize = true;
        l5.Location = new System.Drawing.Point(220, 184);
        txtTongLe.Name = "txtTongLe";
        txtTongLe.Location = new System.Drawing.Point(305, 180);
        txtTongLe.Size = new System.Drawing.Size(75, 24);
        txtTongLe.ReadOnly = true;

        btnTong.Text = "Tổng";
        btnTong.Location = new System.Drawing.Point(360, 137);
        btnTong.Size = new System.Drawing.Size(70, 30);
        btnTong.Click += btnTong_Click;

        btnTongChan.Text = "Tổng chẵn";
        btnTongChan.Location = new System.Drawing.Point(92, 220);
        btnTongChan.Size = new System.Drawing.Size(125, 30);
        btnTongChan.Click += btnTongChan_Click;

        btnTongLe.Text = "Tổng lẻ";
        btnTongLe.Location = new System.Drawing.Point(237, 220);
        btnTongLe.Size = new System.Drawing.Size(105, 30);
        btnTongLe.Click += btnTongLe_Click;

        btnTiepTuc.Text = "Tiếp tục";
        btnTiepTuc.Location = new System.Drawing.Point(115, 270);
        btnTiepTuc.Size = new System.Drawing.Size(95, 35);
        btnTiepTuc.Click += btnTiepTuc_Click;

        btnThoat.Text = "Thoát";
        btnThoat.Location = new System.Drawing.Point(225, 270);
        btnThoat.Size = new System.Drawing.Size(95, 35);
        btnThoat.Click += btnThoat_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, l1, txtNhapSo, btnNhap, l2, txtDayVuaNhap,
            l3, txtTong, btnTong, l4, txtTongChan, l5, txtTongLe,
            btnTongChan, btnTongLe, btnTiepTuc, btnThoat
        });
        FormClosing += Form_FormClosing;
        ResumeLayout(false);
        PerformLayout();
    }
}
