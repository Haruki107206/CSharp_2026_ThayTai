using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmDaySo : Form
{
    private readonly List<int> _daySo = new();

    public FrmDaySo()
    {
        InitializeComponent();
        txtNhapSo.KeyPress += NumberKeyPress;
    }

    private static void NumberKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '-')
            e.Handled = true;
    }

    private bool CoDuLieu()
    {
        if (_daySo.Count == 0)
        {
            MessageBox.Show("Bạn chưa nhập số.");
            txtNhapSo.Focus();
            return false;
        }
        return true;
    }

    private void CapNhatDay()
    {
        txtDayVuaNhap.Text = string.Join(" ", _daySo);
    }

    private void btnNhap_Click(object? sender, EventArgs e)
    {
        if (!int.TryParse(txtNhapSo.Text, out int x))
        {
            MessageBox.Show("Nhập số nguyên hợp lệ.");
            txtNhapSo.Focus();
            return;
        }

        _daySo.Add(x);
        CapNhatDay();
        txtNhapSo.Clear();
        txtNhapSo.Focus();
    }

    private void btnTong_Click(object? sender, EventArgs e)
    {
        if (!CoDuLieu()) return;
        int tong = 0;
        foreach (int x in _daySo) tong += x;
        txtTong.Text = tong.ToString();
    }

    private void btnTongChan_Click(object? sender, EventArgs e)
    {
        if (!CoDuLieu()) return;
        int tong = 0;
        foreach (int x in _daySo) if (x % 2 == 0) tong += x;
        txtTongChan.Text = tong.ToString();
    }

    private void btnTongLe_Click(object? sender, EventArgs e)
    {
        if (!CoDuLieu()) return;
        int tong = 0;
        foreach (int x in _daySo) if (x % 2 != 0) tong += x;
        txtTongLe.Text = tong.ToString();
    }

    private void btnTiepTuc_Click(object? sender, EventArgs e)
    {
        _daySo.Clear();
        txtNhapSo.Clear(); txtDayVuaNhap.Clear(); txtTong.Clear(); txtTongChan.Clear(); txtTongLe.Clear();
        txtNhapSo.Focus();
    }

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
