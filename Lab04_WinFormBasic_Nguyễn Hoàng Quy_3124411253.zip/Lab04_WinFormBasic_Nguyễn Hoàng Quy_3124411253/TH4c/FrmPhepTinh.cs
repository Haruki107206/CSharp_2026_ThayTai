using System;
using System.Globalization;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmPhepTinh : Form
{
    public FrmPhepTinh()
    {
        InitializeComponent();
        txtA.TextChanged += txtNumber_TextChanged;
        txtB.TextChanged += txtNumber_TextChanged;
        txtA.KeyPress += txtNumber_KeyPress;
        txtB.KeyPress += txtNumber_KeyPress;
    }

    private static bool TryParseNumber(string text, out float value)
    {
        text = text.Trim().Replace(',', '.');
        return float.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
    }

    private bool TryGetNumbers(out float a, out float b)
    {
        bool okA = TryParseNumber(txtA.Text, out a);
        bool okB = TryParseNumber(txtB.Text, out b);

        errorProvider1.SetError(txtA, okA ? "" : "A phải là số.");
        errorProvider1.SetError(txtB, okB ? "" : "B phải là số.");
        return okA && okB;
    }

    private void txtNumber_KeyPress(object? sender, KeyPressEventArgs e)
    {
        if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar))
            return;

        TextBox txt = (TextBox)sender!;

        if ((e.KeyChar == '.' || e.KeyChar == ',') &&
            !txt.Text.Contains('.') && !txt.Text.Contains(','))
            return;

        if (e.KeyChar == '-' && txt.SelectionStart == 0 && !txt.Text.Contains('-'))
            return;

        e.Handled = true;
    }

    private void txtNumber_TextChanged(object? sender, EventArgs e)
    {
        if (sender is not TextBox txt)
            return;

        if (string.IsNullOrWhiteSpace(txt.Text))
            errorProvider1.SetError(txt, "Không được để trống.");
        else if (!TryParseNumber(txt.Text, out _))
            errorProvider1.SetError(txt, "Phải nhập số.");
        else
            errorProvider1.Clear();
    }

    private void btnCong_Click(object sender, EventArgs e)
    {
        if (TryGetNumbers(out float a, out float b))
            txtKetQua.Text = (a + b).ToString(CultureInfo.InvariantCulture);
        else
            MessageBox.Show("Dữ liệu a, b không hợp lệ.");
    }

    private void btnTru_Click(object sender, EventArgs e)
    {
        if (TryGetNumbers(out float a, out float b))
            txtKetQua.Text = (a - b).ToString(CultureInfo.InvariantCulture);
        else
            MessageBox.Show("Dữ liệu a, b không hợp lệ.");
    }

    private void btnNhan_Click(object sender, EventArgs e)
    {
        if (TryGetNumbers(out float a, out float b))
            txtKetQua.Text = (a * b).ToString(CultureInfo.InvariantCulture);
        else
            MessageBox.Show("Dữ liệu a, b không hợp lệ.");
    }

    private void btnChia_Click(object sender, EventArgs e)
    {
        if (!TryGetNumbers(out float a, out float b))
        {
            MessageBox.Show("Dữ liệu a, b không hợp lệ.");
            return;
        }

        if (b == 0)
        {
            MessageBox.Show("Không thể chia cho 0.");
            return;
        }

        txtKetQua.Text = (a / b).ToString(CultureInfo.InvariantCulture);
    }

    private void FrmPhepTinh_FormClosing(object? sender, FormClosingEventArgs e)
    {
        DialogResult r = MessageBox.Show(
            "Bạn có muốn thoát?", "Xác nhận",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (r == DialogResult.No)
            e.Cancel = true;
    }
}
