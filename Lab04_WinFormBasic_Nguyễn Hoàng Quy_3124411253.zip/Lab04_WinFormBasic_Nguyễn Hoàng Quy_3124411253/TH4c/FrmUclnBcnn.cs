using System;
using System.Windows.Forms;

namespace WinForms.TH4c;

public partial class FrmUclnBcnn : Form
{
    public FrmUclnBcnn()
    {
        InitializeComponent();
        txtA.KeyPress += NumberKeyPress;
        txtB.KeyPress += NumberKeyPress;
    }

    private static void NumberKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            e.Handled = true;
    }

    private static int Ucln(int a, int b)
    {
        while (b != 0)
        {
            int r = a % b;
            a = b;
            b = r;
        }
        return a;
    }

    private void btnThucHien_Click(object? sender, EventArgs e)
    {
        if (!int.TryParse(txtA.Text, out int a) || !int.TryParse(txtB.Text, out int b) || a <= 0 || b <= 0)
        {
            MessageBox.Show("Vui lòng nhập 2 số nguyên dương.");
            return;
        }

        int ucln = Ucln(a, b);
        long bcnn = (long)a / ucln * b;

        txtUCLN.Text = ucln.ToString();
        txtBCNN.Text = bcnn.ToString();
    }

    private void btnTiepTuc_Click(object? sender, EventArgs e)
    {
        txtA.Clear(); txtB.Clear(); txtUCLN.Clear(); txtBCNN.Clear(); txtA.Focus();
    }

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
