#nullable enable
namespace WinForms.TH4d;

partial class FrmKhachSan
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, lHoTen = null!, lDiaChi = null!, lSoNgay = null!, lThanhTien = null!, lTongLuot = null!, lTongTien = null!;
    private System.Windows.Forms.TextBox txtHoTen = null!, txtDiaChi = null!, txtSoNgay = null!, txtThanhTien = null!, txtTongLuot = null!, txtTongNgayTien = null!;
    private System.Windows.Forms.GroupBox grpPhong = null!, grpTienNghi = null!, grpDichVu = null!;
    private System.Windows.Forms.RadioButton rdoDon = null!, rdoDoi = null!, rdoBa = null!;
    private System.Windows.Forms.CheckBox chkTivi = null!, chkInternet = null!, chkMayNuocNong = null!, chkKaraoke = null!, chkAnSang = null!;
    private System.Windows.Forms.Button btnThanhToan = null!, btnNhapMoi = null!, btnTongKet = null!, btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        lHoTen = new System.Windows.Forms.Label(); lDiaChi = new System.Windows.Forms.Label(); lSoNgay = new System.Windows.Forms.Label(); lThanhTien = new System.Windows.Forms.Label(); lTongLuot = new System.Windows.Forms.Label(); lTongTien = new System.Windows.Forms.Label();
        txtHoTen = new System.Windows.Forms.TextBox(); txtDiaChi = new System.Windows.Forms.TextBox(); txtSoNgay = new System.Windows.Forms.TextBox(); txtThanhTien = new System.Windows.Forms.TextBox(); txtTongLuot = new System.Windows.Forms.TextBox(); txtTongNgayTien = new System.Windows.Forms.TextBox();
        grpPhong = new System.Windows.Forms.GroupBox(); grpTienNghi = new System.Windows.Forms.GroupBox(); grpDichVu = new System.Windows.Forms.GroupBox();
        rdoDon = new System.Windows.Forms.RadioButton(); rdoDoi = new System.Windows.Forms.RadioButton(); rdoBa = new System.Windows.Forms.RadioButton();
        chkTivi = new System.Windows.Forms.CheckBox(); chkInternet = new System.Windows.Forms.CheckBox(); chkMayNuocNong = new System.Windows.Forms.CheckBox(); chkKaraoke = new System.Windows.Forms.CheckBox(); chkAnSang = new System.Windows.Forms.CheckBox();
        btnThanhToan = new System.Windows.Forms.Button(); btnNhapMoi = new System.Windows.Forms.Button(); btnTongKet = new System.Windows.Forms.Button(); btnThoat = new System.Windows.Forms.Button();
        grpPhong.SuspendLayout(); grpTienNghi.SuspendLayout(); grpDichVu.SuspendLayout(); SuspendLayout();

        Name = "FrmKhachSan";
        Text = "frmDangkyKS";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(900, 360);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "KHÁCH SẠN THANH THANH-TRẢ PHÒNG";
        title.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.DarkOrange;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(130, 14);
        title.Size = new System.Drawing.Size(650, 31);

        lHoTen.Text = "Họ và tên:"; lHoTen.AutoSize = true; lHoTen.Location = new System.Drawing.Point(25, 66);
        txtHoTen.Name = "txtHoTen"; txtHoTen.Location = new System.Drawing.Point(135, 62); txtHoTen.Size = new System.Drawing.Size(265, 24);

        lDiaChi.Text = "Địa chỉ:"; lDiaChi.AutoSize = true; lDiaChi.Location = new System.Drawing.Point(25, 99);
        txtDiaChi.Name = "txtDiaChi"; txtDiaChi.Location = new System.Drawing.Point(105, 95); txtDiaChi.Size = new System.Drawing.Size(300, 24);

        lSoNgay.Text = "Số ngày ở:"; lSoNgay.AutoSize = true; lSoNgay.Location = new System.Drawing.Point(25, 132);
        txtSoNgay.Name = "txtSoNgay"; txtSoNgay.Location = new System.Drawing.Point(135, 128); txtSoNgay.Size = new System.Drawing.Size(80, 24); txtSoNgay.KeyPress += NumberKeyPress;

        grpPhong.Text = "Loại phòng"; grpPhong.Location = new System.Drawing.Point(25, 165); grpPhong.Size = new System.Drawing.Size(180, 130);
        rdoDon.Text = "Phòng đơn"; rdoDon.AutoSize = true; rdoDon.Location = new System.Drawing.Point(15, 28);
        rdoDoi.Text = "Phòng đôi"; rdoDoi.AutoSize = true; rdoDoi.Location = new System.Drawing.Point(15, 58);
        rdoBa.Text = "Phòng ba"; rdoBa.AutoSize = true; rdoBa.Location = new System.Drawing.Point(15, 88);
        grpPhong.Controls.AddRange(new System.Windows.Forms.Control[] { rdoDon, rdoDoi, rdoBa });

        grpTienNghi.Text = "Tiện nghi"; grpTienNghi.Location = new System.Drawing.Point(215, 165); grpTienNghi.Size = new System.Drawing.Size(180, 130);
        chkTivi.Text = "Tivi"; chkTivi.AutoSize = true; chkTivi.Location = new System.Drawing.Point(15, 28);
        chkInternet.Text = "Internet"; chkInternet.AutoSize = true; chkInternet.Location = new System.Drawing.Point(15, 58);
        chkMayNuocNong.Text = "Máy nước nóng"; chkMayNuocNong.AutoSize = true; chkMayNuocNong.Location = new System.Drawing.Point(15, 88);
        grpTienNghi.Controls.AddRange(new System.Windows.Forms.Control[] { chkTivi, chkInternet, chkMayNuocNong });

        grpDichVu.Text = "Dịch vụ"; grpDichVu.Location = new System.Drawing.Point(405, 165); grpDichVu.Size = new System.Drawing.Size(155, 130);
        chkKaraoke.Text = "Karaoke"; chkKaraoke.AutoSize = true; chkKaraoke.Location = new System.Drawing.Point(15, 28);
        chkAnSang.Text = "Ăn sáng"; chkAnSang.AutoSize = true; chkAnSang.Location = new System.Drawing.Point(15, 58);
        grpDichVu.Controls.AddRange(new System.Windows.Forms.Control[] { chkKaraoke, chkAnSang });

        btnThanhToan.Text = "Thanh toán"; btnThanhToan.Location = new System.Drawing.Point(555, 68); btnThanhToan.Size = new System.Drawing.Size(120, 32); btnThanhToan.Enabled = false; btnThanhToan.Click += btnThanhToan_Click;
        btnNhapMoi.Text = "Nhập mới"; btnNhapMoi.Location = new System.Drawing.Point(675, 68); btnNhapMoi.Size = new System.Drawing.Size(105, 32); btnNhapMoi.Enabled = false; btnNhapMoi.Click += btnNhapMoi_Click;
        lThanhTien.Text = "Thành tiền:"; lThanhTien.AutoSize = true; lThanhTien.Location = new System.Drawing.Point(555, 111);
        txtThanhTien.Name = "txtThanhTien"; txtThanhTien.Location = new System.Drawing.Point(670, 107); txtThanhTien.Size = new System.Drawing.Size(150, 24); txtThanhTien.ReadOnly = true;
        btnTongKet.Text = "Tổng kết"; btnTongKet.Location = new System.Drawing.Point(555, 148); btnTongKet.Size = new System.Drawing.Size(115, 32); btnTongKet.Enabled = false; btnTongKet.Click += btnTongKet_Click;
        btnThoat.Text = "Thoát"; btnThoat.Location = new System.Drawing.Point(675, 148); btnThoat.Size = new System.Drawing.Size(105, 32); btnThoat.Click += btnThoat_Click;

        lTongLuot.Text = "Số lượt người:"; lTongLuot.AutoSize = true; lTongLuot.Location = new System.Drawing.Point(575, 198);
        txtTongLuot.Name = "txtTongLuot"; txtTongLuot.Location = new System.Drawing.Point(705, 194); txtTongLuot.Size = new System.Drawing.Size(85, 24); txtTongLuot.ReadOnly = true;
        lTongTien.Text = "Tổng số tiền:"; lTongTien.AutoSize = true; lTongTien.Location = new System.Drawing.Point(575, 231);
        txtTongNgayTien.Name = "txtTongNgayTien"; txtTongNgayTien.Location = new System.Drawing.Point(705, 227); txtTongNgayTien.Size = new System.Drawing.Size(150, 24); txtTongNgayTien.ReadOnly = true;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, lHoTen, txtHoTen, lDiaChi, txtDiaChi, lSoNgay, txtSoNgay,
            grpPhong, grpTienNghi, grpDichVu,
            btnThanhToan, btnNhapMoi, lThanhTien, txtThanhTien, btnTongKet, btnThoat,
            lTongLuot, txtTongLuot, lTongTien, txtTongNgayTien
        });
        FormClosing += Form_FormClosing;
        grpPhong.ResumeLayout(false); grpPhong.PerformLayout();
        grpTienNghi.ResumeLayout(false); grpTienNghi.PerformLayout();
        grpDichVu.ResumeLayout(false); grpDichVu.PerformLayout();
        ResumeLayout(false); PerformLayout();
    }
}
