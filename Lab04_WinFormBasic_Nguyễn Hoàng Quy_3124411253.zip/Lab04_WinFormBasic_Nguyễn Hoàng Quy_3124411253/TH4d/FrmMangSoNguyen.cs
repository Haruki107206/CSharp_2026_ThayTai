using System;
using System.Windows.Forms;

namespace WinForms.TH4d;

public partial class FrmMangSoNguyen : Form
{
    private readonly MangSoNguyen _mang = new();

    public FrmMangSoNguyen() => InitializeComponent();

    private bool CoMang()
    {
        if (_mang.A.Length == 0)
        {
            MessageBox.Show("Bạn chưa nhập mảng.");
            return false;
        }
        return true;
    }

    private void CapNhatKetQua() => txtKetQua.Text = _mang.Xuat();

    private void btnNhap_Click(object? sender, EventArgs e)
    {
        try
        {
            _mang.Nhap(txtNhapMang.Text);
            CapNhatKetQua();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }

    private void btnReset_Click(object? sender, EventArgs e)
    {
        _mang.Nhap("0");
        _mang.XoaViTri(0);
        txtNhapMang.Clear(); txtKetQua.Clear(); txtTimKiem.Clear(); txtKetQuaTim.Clear();
        txtThem.Clear(); txtViTriThem.Clear(); txtTong.Clear(); txtTongChan.Clear(); txtTongLe.Clear();
        txtMax.Clear(); txtMin.Clear(); txtXoa.Clear(); txtViTriXoa.Clear(); txtThayCu.Clear(); txtViTriThay.Clear(); txtThayMoi.Clear();
    }

    private void btnThucHien_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        if (rdoTang.Checked) _mang.SapXepTang(); else _mang.SapXepGiam();
        CapNhatKetQua();
    }

    private void btnTimKiem_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        try
        {
            if (rdoTimGiaTri.Checked)
            {
                if (!int.TryParse(txtTimKiem.Text, out int value)) { MessageBox.Show("Nhập giá trị cần tìm."); return; }
                int position = _mang.TimGiaTri(value);
                txtKetQuaTim.Text = position == -1 ? "Không tìm thấy" : "Vị trí: " + position;
            }
            else
            {
                if (!int.TryParse(txtTimKiem.Text, out int position)) { MessageBox.Show("Nhập vị trí cần tìm."); return; }
                txtKetQuaTim.Text = _mang.TimViTri(position).ToString();
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message); }
    }

    private void btnXoa_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        try
        {
            bool ok;
            if (rdoXoaGiaTri.Checked)
            {
                if (!int.TryParse(txtXoa.Text, out int value)) { MessageBox.Show("Nhập giá trị cần xóa."); return; }
                ok = _mang.XoaGiaTri(value);
            }
            else
            {
                if (!int.TryParse(txtViTriXoa.Text, out int position)) { MessageBox.Show("Nhập vị trí cần xóa."); return; }
                _mang.XoaViTri(position); ok = true;
            }
            if (!ok) { MessageBox.Show("Không tìm thấy giá trị cần xóa."); return; }
            CapNhatKetQua();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message); }
    }

    private void btnThem_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        if (!int.TryParse(txtThem.Text, out int value) || !int.TryParse(txtViTriThem.Text, out int position))
        { MessageBox.Show("Giá trị và vị trí phải là số nguyên."); return; }
        try { _mang.Them(value, position); CapNhatKetQua(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
    }

    private void btnTong_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        txtTong.Text = _mang.Tong().ToString(); txtTongChan.Text = _mang.TongChan().ToString(); txtTongLe.Text = _mang.TongLe().ToString();
    }

    private void btnTimMaxMin_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;
        txtMax.Text = _mang.Max().ToString(); txtMin.Text = _mang.Min().ToString();
    }

    private void btnThay_Click(object? sender, EventArgs e)
    {
        if (!CoMang()) return;

        try
        {
            if (!int.TryParse(txtThayMoi.Text, out int newValue)) { MessageBox.Show("Nhập số thay thế."); return; }

            if (rdoThayGiaTri.Checked)
            {
                if (!int.TryParse(txtThayCu.Text, out int oldValue)) { MessageBox.Show("Nhập giá trị cần thay thế."); return; }
                if (!_mang.ThayGiaTri(oldValue, newValue)) { MessageBox.Show("Không tìm thấy giá trị cần thay."); return; }
            }
            else
            {
                if (!int.TryParse(txtViTriThay.Text, out int position)) { MessageBox.Show("Nhập vị trí cần thay thế."); return; }
                _mang.ThayViTri(position, newValue);
            }
            CapNhatKetQua();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message); }
    }

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
