#nullable enable
namespace WinForms.TH4d;

partial class FrmPhuongTrinh
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, la = null!, lb = null!, lc = null!, lq = null!;
    private System.Windows.Forms.RadioButton rdoBacNhat = null!, rdoBacHai = null!;
    private System.Windows.Forms.TextBox txtA = null!, txtB = null!, txtC = null!, txtKetQua = null!;
    private System.Windows.Forms.Button btnGiai = null!, btnThoat = null!;
    private System.Windows.Forms.GroupBox grp = null!;
    private System.Windows.Forms.ErrorProvider errorProvider1 = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        grp = new System.Windows.Forms.GroupBox();
        rdoBacNhat = new System.Windows.Forms.RadioButton();
        rdoBacHai = new System.Windows.Forms.RadioButton();
        la = new System.Windows.Forms.Label(); lb = new System.Windows.Forms.Label(); lc = new System.Windows.Forms.Label(); lq = new System.Windows.Forms.Label();
        txtA = new System.Windows.Forms.TextBox(); txtB = new System.Windows.Forms.TextBox(); txtC = new System.Windows.Forms.TextBox(); txtKetQua = new System.Windows.Forms.TextBox();
        btnGiai = new System.Windows.Forms.Button(); btnThoat = new System.Windows.Forms.Button();
        errorProvider1 = new System.Windows.Forms.ErrorProvider(components);
        ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
        grp.SuspendLayout();
        SuspendLayout();

        Name = "FrmPhuongTrinh";
        Text = "Giải phương trình bậc 1-2";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(360, 380);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "GIẢI PHƯƠNG TRÌNH";
        title.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.Red;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(55, 14);
        title.Size = new System.Drawing.Size(250, 31);

        grp.Text = "Bạn vui lòng chọn";
        grp.Location = new System.Drawing.Point(20, 58);
        grp.Size = new System.Drawing.Size(320, 92);

        rdoBacNhat.Text = "Phương trình bậc nhất";
        rdoBacNhat.AutoSize = true;
        rdoBacNhat.Location = new System.Drawing.Point(25, 29);
        rdoBacNhat.CheckedChanged += rdo_CheckedChanged;

        rdoBacHai.Text = "Phương trình bậc hai";
        rdoBacHai.AutoSize = true;
        rdoBacHai.Location = new System.Drawing.Point(25, 59);
        rdoBacHai.CheckedChanged += rdo_CheckedChanged;

        grp.Controls.AddRange(new System.Windows.Forms.Control[] { rdoBacNhat, rdoBacHai });

        la.Text = "Nhập a";
        la.AutoSize = true;
        la.Location = new System.Drawing.Point(35, 178);
        txtA.Name = "txtA";
        txtA.Location = new System.Drawing.Point(105, 174);
        txtA.Size = new System.Drawing.Size(125, 24);

        lb.Text = "Nhập b";
        lb.AutoSize = true;
        lb.Location = new System.Drawing.Point(35, 218);
        txtB.Name = "txtB";
        txtB.Location = new System.Drawing.Point(105, 214);
        txtB.Size = new System.Drawing.Size(125, 24);

        lc.Text = "Nhập c";
        lc.AutoSize = true;
        lc.Location = new System.Drawing.Point(35, 258);
        txtC.Name = "txtC";
        txtC.Location = new System.Drawing.Point(105, 254);
        txtC.Size = new System.Drawing.Size(125, 24);

        lq.Text = "Kết quả";
        lq.AutoSize = true;
        lq.Location = new System.Drawing.Point(35, 312);
        txtKetQua.Name = "txtKetQua";
        txtKetQua.Location = new System.Drawing.Point(115, 302);
        txtKetQua.Size = new System.Drawing.Size(225, 50);
        txtKetQua.Multiline = true;
        txtKetQua.ReadOnly = true;
        txtKetQua.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;

        btnGiai.Text = "Giải";
        btnGiai.Location = new System.Drawing.Point(250, 173);
        btnGiai.Size = new System.Drawing.Size(75, 38);
        btnGiai.Enabled = false;
        btnGiai.Click += btnGiai_Click;

        btnThoat.Text = "Thoát";
        btnThoat.Location = new System.Drawing.Point(250, 218);
        btnThoat.Size = new System.Drawing.Size(75, 38);
        btnThoat.Click += btnThoat_Click;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, grp, la, txtA, lb, txtB, lc, txtC, lq, txtKetQua, btnGiai, btnThoat
        });
        FormClosing += Form_FormClosing;
        ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
        grp.ResumeLayout(false);
        grp.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
}
