#nullable enable
namespace WinForms.TH4d;

partial class FrmCafeSinhVien
{
    private System.ComponentModel.IContainer? components = null;
    private System.Windows.Forms.Label title = null!, lblTen = null!, lblSoKhach = null!, lblTongKhach = null!, lblTongTien = null!;
    private System.Windows.Forms.TextBox txtTenKhach = null!, txtSoKhach = null!, txtTongKhach = null!, txtTongTien = null!;
    private System.Windows.Forms.CheckBox chkSinhVien = null!, chkBanhTrung = null!, chkBanhCa = null!, chkMyTom = null!, chkMyXao = null!, chkMyCay = null!;
    private System.Windows.Forms.RadioButton rdoDen = null!, rdoDa = null!, rdoSua = null!, rdoSuaDa = null!, rdoKem = null!;
    private System.Windows.Forms.GroupBox grpCafe = null!, grpThucAn = null!;
    private System.Windows.Forms.Button btnTinhTien = null!, btnNhapLai = null!, btnThanhToan = null!, btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        title = new System.Windows.Forms.Label();
        lblTen = new System.Windows.Forms.Label();
        lblSoKhach = new System.Windows.Forms.Label();
        lblTongKhach = new System.Windows.Forms.Label();
        lblTongTien = new System.Windows.Forms.Label();
        txtTenKhach = new System.Windows.Forms.TextBox();
        txtSoKhach = new System.Windows.Forms.TextBox();
        txtTongKhach = new System.Windows.Forms.TextBox();
        txtTongTien = new System.Windows.Forms.TextBox();
        chkSinhVien = new System.Windows.Forms.CheckBox();
        chkBanhTrung = new System.Windows.Forms.CheckBox(); chkBanhCa = new System.Windows.Forms.CheckBox(); chkMyTom = new System.Windows.Forms.CheckBox(); chkMyXao = new System.Windows.Forms.CheckBox(); chkMyCay = new System.Windows.Forms.CheckBox();
        rdoDen = new System.Windows.Forms.RadioButton(); rdoDa = new System.Windows.Forms.RadioButton(); rdoSua = new System.Windows.Forms.RadioButton(); rdoSuaDa = new System.Windows.Forms.RadioButton(); rdoKem = new System.Windows.Forms.RadioButton();
        grpCafe = new System.Windows.Forms.GroupBox(); grpThucAn = new System.Windows.Forms.GroupBox();
        btnTinhTien = new System.Windows.Forms.Button(); btnNhapLai = new System.Windows.Forms.Button(); btnThanhToan = new System.Windows.Forms.Button(); btnThoat = new System.Windows.Forms.Button();
        grpCafe.SuspendLayout(); grpThucAn.SuspendLayout(); SuspendLayout();

        Name = "FrmCafeSinhVien";
        Text = "Thanh toán tiền";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(590, 490);
        Font = new System.Drawing.Font("Tahoma", 10F);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        title.Text = "CAFE SINH VIÊN";
        title.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.DarkOrange;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(145, 16);
        title.Size = new System.Drawing.Size(320, 30);

        lblTen.Text = "Tên khách hàng";
        lblTen.AutoSize = true;
        lblTen.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
        lblTen.Location = new System.Drawing.Point(30, 60);
        txtTenKhach.Name = "txtTenKhach";
        txtTenKhach.Location = new System.Drawing.Point(205, 56);
        txtTenKhach.Size = new System.Drawing.Size(300, 24);

        lblSoKhach.Text = "Số khách hàng";
        lblSoKhach.AutoSize = true;
        lblSoKhach.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
        lblSoKhach.Location = new System.Drawing.Point(30, 91);
        txtSoKhach.Name = "txtSoKhach";
        txtSoKhach.Location = new System.Drawing.Point(195, 87);
        txtSoKhach.Size = new System.Drawing.Size(90, 24);
        txtSoKhach.KeyPress += NumberKeyPress;

        chkSinhVien.Text = "Sinh viên ?";
        chkSinhVien.AutoSize = true;
        chkSinhVien.Location = new System.Drawing.Point(310, 88);

        grpCafe.Text = "Nước uống";
        grpCafe.Location = new System.Drawing.Point(22, 120);
        grpCafe.Size = new System.Drawing.Size(255, 175);

        rdoDen.Text = "Cafe đen"; rdoDen.AutoSize = true; rdoDen.Location = new System.Drawing.Point(18, 27);
        rdoDa.Text = "Cafe đá"; rdoDa.AutoSize = true; rdoDa.Location = new System.Drawing.Point(18, 55);
        rdoSua.Text = "Cafe sữa"; rdoSua.AutoSize = true; rdoSua.Location = new System.Drawing.Point(18, 83);
        rdoSuaDa.Text = "Cafe sữa đá"; rdoSuaDa.AutoSize = true; rdoSuaDa.Location = new System.Drawing.Point(18, 111);
        rdoKem.Text = "Cafe kem"; rdoKem.AutoSize = true; rdoKem.Location = new System.Drawing.Point(18, 139);
        grpCafe.Controls.AddRange(new System.Windows.Forms.Control[] { rdoDen, rdoDa, rdoSua, rdoSuaDa, rdoKem });

        grpThucAn.Text = "Thức ăn";
        grpThucAn.Location = new System.Drawing.Point(290, 120);
        grpThucAn.Size = new System.Drawing.Size(255, 175);

        chkBanhTrung.Text = "Bánh mì trứng"; chkBanhTrung.AutoSize = true; chkBanhTrung.Location = new System.Drawing.Point(15, 27);
        chkBanhCa.Text = "Bánh mì cá"; chkBanhCa.AutoSize = true; chkBanhCa.Location = new System.Drawing.Point(15, 55);
        chkMyTom.Text = "Mỳ tôm trứng"; chkMyTom.AutoSize = true; chkMyTom.Location = new System.Drawing.Point(15, 83);
        chkMyXao.Text = "Mỳ xào bò"; chkMyXao.AutoSize = true; chkMyXao.Location = new System.Drawing.Point(15, 111);
        chkMyCay.Text = "Mỳ cay"; chkMyCay.AutoSize = true; chkMyCay.Location = new System.Drawing.Point(15, 139);
        grpThucAn.Controls.AddRange(new System.Windows.Forms.Control[] { chkBanhTrung, chkBanhCa, chkMyTom, chkMyXao, chkMyCay });

        btnTinhTien.Text = "Tính tiền"; btnTinhTien.Location = new System.Drawing.Point(22, 310); btnTinhTien.Size = new System.Drawing.Size(105, 34); btnTinhTien.Enabled = false; btnTinhTien.Click += btnTinhTien_Click;
        btnNhapLai.Text = "Nhập lại"; btnNhapLai.Location = new System.Drawing.Point(157, 310); btnNhapLai.Size = new System.Drawing.Size(105, 34); btnNhapLai.Enabled = false; btnNhapLai.Click += btnNhapLai_Click;
        btnThanhToan.Text = "Thanh toán"; btnThanhToan.Location = new System.Drawing.Point(292, 310); btnThanhToan.Size = new System.Drawing.Size(105, 34); btnThanhToan.Enabled = false; btnThanhToan.Click += btnThanhToan_Click;
        btnThoat.Text = "Thoát"; btnThoat.Location = new System.Drawing.Point(427, 310); btnThoat.Size = new System.Drawing.Size(105, 34); btnThoat.Click += btnThoat_Click;

        lblTongKhach.Text = "Tổng khách hàng"; lblTongKhach.AutoSize = true; lblTongKhach.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold); lblTongKhach.Location = new System.Drawing.Point(22, 358);
        txtTongKhach.Name = "txtTongKhach"; txtTongKhach.Location = new System.Drawing.Point(205, 351); txtTongKhach.Size = new System.Drawing.Size(80, 24); txtTongKhach.ReadOnly = true;
        lblTongTien.Text = "Tổng tiền thanh toán"; lblTongTien.AutoSize = true; lblTongTien.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold); lblTongTien.Location = new System.Drawing.Point(22, 408);
        txtTongTien.Name = "txtTongTien"; txtTongTien.Location = new System.Drawing.Point(245, 401); txtTongTien.Size = new System.Drawing.Size(150, 24); txtTongTien.ReadOnly = true;

        Controls.AddRange(new System.Windows.Forms.Control[]
        {
            title, lblTen, txtTenKhach, lblSoKhach, txtSoKhach, chkSinhVien,
            grpCafe, grpThucAn, btnTinhTien, btnNhapLai, btnThanhToan, btnThoat,
            lblTongKhach, txtTongKhach, lblTongTien, txtTongTien
        });
        FormClosing += Form_FormClosing;
        grpCafe.ResumeLayout(false); grpCafe.PerformLayout();
        grpThucAn.ResumeLayout(false); grpThucAn.PerformLayout();
        ResumeLayout(false); PerformLayout();
    }
}
