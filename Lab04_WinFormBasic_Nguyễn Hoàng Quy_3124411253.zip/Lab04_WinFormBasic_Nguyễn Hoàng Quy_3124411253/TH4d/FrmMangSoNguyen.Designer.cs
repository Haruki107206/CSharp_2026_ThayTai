#nullable enable
namespace WinForms.TH4d;

partial class FrmMangSoNguyen
{
    private System.ComponentModel.IContainer? components = null;

    private System.Windows.Forms.Label title = null!;
    private System.Windows.Forms.Label lNhap = null!, lKet = null!, lTK = null!, lKQTK = null!, lXoa = null!, lThem = null!, lVT = null!, lTong = null!, lChan = null!, lLe = null!, lMax = null!, lMin = null!, lThayCu = null!, lVTThay = null!, lThayMoi = null!;
    private System.Windows.Forms.Label lCanSapXepXoa = null!, lCanSapXepThem = null!;

    private System.Windows.Forms.TextBox txtNhapMang = null!, txtKetQua = null!, txtTimKiem = null!, txtKetQuaTim = null!, txtXoa = null!, txtViTriXoa = null!, txtThem = null!, txtViTriThem = null!, txtTong = null!, txtTongChan = null!, txtTongLe = null!, txtMax = null!, txtMin = null!, txtThayCu = null!, txtViTriThay = null!, txtThayMoi = null!;
    private System.Windows.Forms.Button btnNhap = null!, btnReset = null!, btnThucHien = null!, btnTimKiem = null!, btnXoa = null!, btnThem = null!, btnTong = null!, btnTimMaxMin = null!, btnThay = null!, btnThoat = null!;
    private System.Windows.Forms.RadioButton rdoTang = null!, rdoGiam = null!, rdoTimGiaTri = null!, rdoTimViTri = null!, rdoXoaGiaTri = null!, rdoXoaViTri = null!, rdoThayGiaTri = null!, rdoThayViTri = null!;
    private System.Windows.Forms.GroupBox grpSort = null!, grpTim = null!, grpXoa = null!, grpThem = null!, grpThay = null!, grpThongKe = null!, grpMaxMin = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        title = new System.Windows.Forms.Label();
        lNhap = new System.Windows.Forms.Label();
        lKet = new System.Windows.Forms.Label();
        lTK = new System.Windows.Forms.Label();
        lKQTK = new System.Windows.Forms.Label();
        lXoa = new System.Windows.Forms.Label();
        lThem = new System.Windows.Forms.Label();
        lVT = new System.Windows.Forms.Label();
        lTong = new System.Windows.Forms.Label();
        lChan = new System.Windows.Forms.Label();
        lLe = new System.Windows.Forms.Label();
        lMax = new System.Windows.Forms.Label();
        lMin = new System.Windows.Forms.Label();
        lThayCu = new System.Windows.Forms.Label();
        lVTThay = new System.Windows.Forms.Label();
        lThayMoi = new System.Windows.Forms.Label();
        lCanSapXepXoa = new System.Windows.Forms.Label();
        lCanSapXepThem = new System.Windows.Forms.Label();

        txtNhapMang = new System.Windows.Forms.TextBox();
        txtKetQua = new System.Windows.Forms.TextBox();
        txtTimKiem = new System.Windows.Forms.TextBox();
        txtKetQuaTim = new System.Windows.Forms.TextBox();
        txtXoa = new System.Windows.Forms.TextBox();
        txtViTriXoa = new System.Windows.Forms.TextBox();
        txtThem = new System.Windows.Forms.TextBox();
        txtViTriThem = new System.Windows.Forms.TextBox();
        txtTong = new System.Windows.Forms.TextBox();
        txtTongChan = new System.Windows.Forms.TextBox();
        txtTongLe = new System.Windows.Forms.TextBox();
        txtMax = new System.Windows.Forms.TextBox();
        txtMin = new System.Windows.Forms.TextBox();
        txtThayCu = new System.Windows.Forms.TextBox();
        txtViTriThay = new System.Windows.Forms.TextBox();
        txtThayMoi = new System.Windows.Forms.TextBox();

        btnNhap = new System.Windows.Forms.Button();
        btnReset = new System.Windows.Forms.Button();
        btnThucHien = new System.Windows.Forms.Button();
        btnTimKiem = new System.Windows.Forms.Button();
        btnXoa = new System.Windows.Forms.Button();
        btnThem = new System.Windows.Forms.Button();
        btnTong = new System.Windows.Forms.Button();
        btnTimMaxMin = new System.Windows.Forms.Button();
        btnThay = new System.Windows.Forms.Button();
        btnThoat = new System.Windows.Forms.Button();

        rdoTang = new System.Windows.Forms.RadioButton();
        rdoGiam = new System.Windows.Forms.RadioButton();
        rdoTimGiaTri = new System.Windows.Forms.RadioButton();
        rdoTimViTri = new System.Windows.Forms.RadioButton();
        rdoXoaGiaTri = new System.Windows.Forms.RadioButton();
        rdoXoaViTri = new System.Windows.Forms.RadioButton();
        rdoThayGiaTri = new System.Windows.Forms.RadioButton();
        rdoThayViTri = new System.Windows.Forms.RadioButton();

        grpSort = new System.Windows.Forms.GroupBox();
        grpTim = new System.Windows.Forms.GroupBox();
        grpXoa = new System.Windows.Forms.GroupBox();
        grpThem = new System.Windows.Forms.GroupBox();
        grpThay = new System.Windows.Forms.GroupBox();
        grpThongKe = new System.Windows.Forms.GroupBox();
        grpMaxMin = new System.Windows.Forms.GroupBox();

        grpSort.SuspendLayout();
        grpTim.SuspendLayout();
        grpXoa.SuspendLayout();
        grpThem.SuspendLayout();
        grpThay.SuspendLayout();
        grpThongKe.SuspendLayout();
        grpMaxMin.SuspendLayout();
        SuspendLayout();

        Name = "FrmMangSoNguyen";
        Text = "Mảng Số Nguyên";
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        ClientSize = new System.Drawing.Size(760, 700);
        Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        MinimizeBox = false;

        // Title
        title.Text = "Mảng Số Nguyên";
        title.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold);
        title.ForeColor = System.Drawing.Color.Red;
        title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        title.Location = new System.Drawing.Point(0, 10);
        title.Size = new System.Drawing.Size(700, 40);

        // Nhập mảng
        lNhap.Text = "Nhập mảng:";
        lNhap.Location = new System.Drawing.Point(20, 60);
        lNhap.Size = new System.Drawing.Size(90, 25);
        lNhap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtNhapMang.Name = "txtNhapMang";
        txtNhapMang.Location = new System.Drawing.Point(120, 60);
        txtNhapMang.Size = new System.Drawing.Size(440, 23);

        btnNhap.Text = "Nhập";
        btnNhap.Location = new System.Drawing.Point(575, 58);
        btnNhap.Size = new System.Drawing.Size(72, 27);
        btnNhap.Click += btnNhap_Click;

        btnReset.Text = "Reset";
        btnReset.Location = new System.Drawing.Point(655, 58);
        btnReset.Size = new System.Drawing.Size(72, 27);
        btnReset.Click += btnReset_Click;

        // Kết quả mảng
        lKet.Text = "Kết quả:";
        lKet.Location = new System.Drawing.Point(20, 95);
        lKet.Size = new System.Drawing.Size(95, 25);
        lKet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtKetQua.Name = "txtKetQua";
        txtKetQua.Location = new System.Drawing.Point(120, 95);
        txtKetQua.Size = new System.Drawing.Size(500, 23);
        txtKetQua.ReadOnly = true;

        btnThoat.Text = "Thoát";
        btnThoat.Location = new System.Drawing.Point(650, 93);
        btnThoat.Size = new System.Drawing.Size(72, 27);
        btnThoat.Click += (s, e) => Close();

        // Thực hiện + Sắp xếp
        btnThucHien.Text = "Thực hiện";
        btnThucHien.Location = new System.Drawing.Point(20, 134);
        btnThucHien.Size = new System.Drawing.Size(100, 55);
        btnThucHien.Click += btnThucHien_Click;

        grpSort.Text = "Sắp xếp";
        grpSort.Location = new System.Drawing.Point(120, 130);
        grpSort.Size = new System.Drawing.Size(540, 60);

        rdoTang.Text = "Sắp xếp Tăng";
        rdoTang.AutoSize = true;
        rdoTang.Checked = true;
        rdoTang.Location = new System.Drawing.Point(18, 20);

        rdoGiam.Text = "Sắp xếp Giảm";
        rdoGiam.AutoSize = true;
        rdoGiam.Location = new System.Drawing.Point(250, 20);

        grpSort.Controls.AddRange(new System.Windows.Forms.Control[] { rdoTang, rdoGiam });

        // Tìm kiếm
        grpTim.Text = "Tìm Kiếm";
        grpTim.Location = new System.Drawing.Point(20, 200);
        grpTim.Size = new System.Drawing.Size(315, 150);

        rdoTimGiaTri.Text = "Tìm giá trị cần tìm";
        rdoTimGiaTri.AutoSize = true;
        rdoTimGiaTri.Checked = true;
        rdoTimGiaTri.Location = new System.Drawing.Point(12, 22);

        rdoTimViTri.Text = "Tìm vị trí cần tìm";
        rdoTimViTri.AutoSize = true;
        rdoTimViTri.Location = new System.Drawing.Point(12, 45);

        lTK.Text = "Giá trị:";
        lTK.Location = new System.Drawing.Point(12, 72);
        lTK.Size = new System.Drawing.Size(70, 23);
        lTK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtTimKiem.Name = "txtTimKiem";
        txtTimKiem.Location = new System.Drawing.Point(80, 72);
        txtTimKiem.Size = new System.Drawing.Size(80, 23);

        btnTimKiem.Text = "Tìm";
        btnTimKiem.Location = new System.Drawing.Point(170, 71);
        btnTimKiem.Size = new System.Drawing.Size(110, 26);
        btnTimKiem.Click += btnTimKiem_Click;

        lKQTK.Text = "Kết quả:";
        lKQTK.Location = new System.Drawing.Point(12, 105);
        lKQTK.Size = new System.Drawing.Size(80, 23);
        lKQTK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtKetQuaTim.Name = "txtKetQuaTim";
        txtKetQuaTim.Location = new System.Drawing.Point(90, 104);
        txtKetQuaTim.Size = new System.Drawing.Size(180, 23);
        txtKetQuaTim.ReadOnly = true;

        grpTim.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            rdoTimGiaTri, rdoTimViTri, lTK, txtTimKiem, btnTimKiem, lKQTK, txtKetQuaTim
        });

        // Xóa
        grpXoa.Text = "Xóa";
        grpXoa.Location = new System.Drawing.Point(355, 200);
        grpXoa.Size = new System.Drawing.Size(315, 150);

        rdoXoaGiaTri.Text = "Giá trị cần xóa";
        rdoXoaGiaTri.AutoSize = true;
        rdoXoaGiaTri.Checked = true;
        rdoXoaGiaTri.Location = new System.Drawing.Point(12, 22);

        txtXoa.Name = "txtXoa";
        txtXoa.Location = new System.Drawing.Point(180, 20);
        txtXoa.Size = new System.Drawing.Size(90, 23);

        rdoXoaViTri.Text = "Vị trí cần xóa";
        rdoXoaViTri.AutoSize = true;
        rdoXoaViTri.Location = new System.Drawing.Point(12, 48);

        txtViTriXoa.Name = "txtViTriXoa";
        txtViTriXoa.Location = new System.Drawing.Point(180, 46);
        txtViTriXoa.Size = new System.Drawing.Size(90, 23);

        btnXoa.Text = "Xóa";
        btnXoa.Location = new System.Drawing.Point(180, 78);
        btnXoa.Size = new System.Drawing.Size(110, 26);
        btnXoa.Click += btnXoa_Click;

        lCanSapXepXoa.Text = "* Cần sắp xếp tăng";
        lCanSapXepXoa.ForeColor = System.Drawing.Color.Red;
        lCanSapXepXoa.Font = new System.Drawing.Font("Tahoma", 8.5F);
        lCanSapXepXoa.Location = new System.Drawing.Point(10, 110);
        lCanSapXepXoa.Size = new System.Drawing.Size(260, 20);
        lCanSapXepXoa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

        grpXoa.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            rdoXoaGiaTri, txtXoa, rdoXoaViTri, txtViTriXoa, btnXoa, lCanSapXepXoa
        });

        // Thêm
        grpThem.Text = "Thêm";
        grpThem.Location = new System.Drawing.Point(20, 365);
        grpThem.Size = new System.Drawing.Size(315, 150);

        lThem.Text = "Giá trị cần thêm:";
        lThem.Location = new System.Drawing.Point(12, 24);
        lThem.Size = new System.Drawing.Size(165, 23);
        lThem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtThem.Name = "txtThem";
        txtThem.Location = new System.Drawing.Point(185, 23);
        txtThem.Size = new System.Drawing.Size(95, 23);

        lVT.Text = "Tại vị trí:";
        lVT.Location = new System.Drawing.Point(12, 54);
        lVT.Size = new System.Drawing.Size(120, 23);
        lVT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtViTriThem.Name = "txtViTriThem";
        txtViTriThem.Location = new System.Drawing.Point(185, 53);
        txtViTriThem.Size = new System.Drawing.Size(95, 23);

        btnThem.Text = "Thêm";
        btnThem.Location = new System.Drawing.Point(185, 85);
        btnThem.Size = new System.Drawing.Size(95, 28);
        btnThem.Click += btnThem_Click;

        lCanSapXepThem.Text = "* Cần sắp xếp tăng";
        lCanSapXepThem.ForeColor = System.Drawing.Color.Red;
        lCanSapXepThem.Font = new System.Drawing.Font("Tahoma", 8.5F);
        lCanSapXepThem.Location = new System.Drawing.Point(10, 110);
        lCanSapXepThem.Size = new System.Drawing.Size(260, 20);
        lCanSapXepThem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

        grpThem.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lThem, txtThem, lVT, txtViTriThem, btnThem, lCanSapXepThem
        });

        // Tổng
        grpThongKe.Text = "Tổng";
        grpThongKe.Location = new System.Drawing.Point(355, 365);
        grpThongKe.Size = new System.Drawing.Size(315, 150);

        lTong.Text = "Tổng mảng:";
        lTong.Location = new System.Drawing.Point(12, 24);
        lTong.Size = new System.Drawing.Size(110, 23);
        lTong.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtTong.Name = "txtTong";
        txtTong.Location = new System.Drawing.Point(120, 23);
        txtTong.Size = new System.Drawing.Size(70, 23);
        txtTong.ReadOnly = true;

        lChan.Text = "Tổng chẵn:";
        lChan.Location = new System.Drawing.Point(12, 54);
        lChan.Size = new System.Drawing.Size(105, 23);
        lChan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtTongChan.Name = "txtTongChan";
        txtTongChan.Location = new System.Drawing.Point(120, 53);
        txtTongChan.Size = new System.Drawing.Size(70, 23);
        txtTongChan.ReadOnly = true;

        lLe.Text = "Tổng lẻ:";
        lLe.Location = new System.Drawing.Point(12, 84);
        lLe.Size = new System.Drawing.Size(105, 23);
        lLe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtTongLe.Name = "txtTongLe";
        txtTongLe.Location = new System.Drawing.Point(120, 83);
        txtTongLe.Size = new System.Drawing.Size(70, 23);
        txtTongLe.ReadOnly = true;

        btnTong.Text = "Tổng";
        btnTong.Location = new System.Drawing.Point(210, 23);
        btnTong.Size = new System.Drawing.Size(60, 33);
        btnTong.Click += btnTong_Click;

        grpThongKe.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lTong, txtTong, lChan, txtTongChan, lLe, txtTongLe, btnTong
        });

        // Max - Min
        grpMaxMin.Text = "Max - Min";
        grpMaxMin.Location = new System.Drawing.Point(20, 525);
        grpMaxMin.Size = new System.Drawing.Size(315, 120);

        lMax.Text = "Giá trị lớn nhất:";
        lMax.Location = new System.Drawing.Point(12, 25);
        lMax.Size = new System.Drawing.Size(120, 23);
        lMax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtMax.Name = "txtMax";
        txtMax.Location = new System.Drawing.Point(135, 24);
        txtMax.Size = new System.Drawing.Size(60, 23);
        txtMax.ReadOnly = true;

        lMin.Text = "Giá trị nhỏ nhất:";
        lMin.Location = new System.Drawing.Point(12, 58);
        lMin.Size = new System.Drawing.Size(120, 23);
        lMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtMin.Name = "txtMin";
        txtMin.Location = new System.Drawing.Point(135, 57);
        txtMin.Size = new System.Drawing.Size(60, 23);
        txtMin.ReadOnly = true;

        btnTimMaxMin.Text = "Tìm";
        btnTimMaxMin.Location = new System.Drawing.Point(210, 24);
        btnTimMaxMin.Size = new System.Drawing.Size(80, 56);
        btnTimMaxMin.Click += btnTimMaxMin_Click;

        grpMaxMin.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            lMax, txtMax, lMin, txtMin, btnTimMaxMin
        });

        // Thay Thế
        grpThay.Text = "Thay Thế";
        grpThay.Location = new System.Drawing.Point(355, 525);
        grpThay.Size = new System.Drawing.Size(315, 120);

        rdoThayGiaTri.Text = "Giá trị cần thay";
        rdoThayGiaTri.AutoSize = true;
        rdoThayGiaTri.Checked = true;
        rdoThayGiaTri.Location = new System.Drawing.Point(12, 22);

        txtThayCu.Name = "txtThayCu";
        txtThayCu.Location = new System.Drawing.Point(175, 20);
        txtThayCu.Size = new System.Drawing.Size(95, 23);

        rdoThayViTri.Text = "Vị trí cần thay";
        rdoThayViTri.AutoSize = true;
        rdoThayViTri.Location = new System.Drawing.Point(12, 48);

        txtViTriThay.Name = "txtViTriThay";
        txtViTriThay.Location = new System.Drawing.Point(175, 46);
        txtViTriThay.Size = new System.Drawing.Size(95, 23);

        lThayMoi.Text = "Số thay thế:";
        lThayMoi.Location = new System.Drawing.Point(12, 80);
        lThayMoi.Size = new System.Drawing.Size(115, 23);
        lThayMoi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

        txtThayMoi.Name = "txtThayMoi";
        txtThayMoi.Location = new System.Drawing.Point(130, 79);
        txtThayMoi.Size = new System.Drawing.Size(75, 23);

        btnThay.Text = "Thay";
        btnThay.Location = new System.Drawing.Point(215, 77);
        btnThay.Size = new System.Drawing.Size(95, 35);
        btnThay.Click += btnThay_Click;

        grpThay.Controls.AddRange(new System.Windows.Forms.Control[]
        {
            rdoThayGiaTri, txtThayCu, rdoThayViTri, txtViTriThay, lThayMoi, txtThayMoi, btnThay
        });

        Controls.Add(title);
        Controls.Add(lNhap);
        Controls.Add(txtNhapMang);
        Controls.Add(btnNhap);
        Controls.Add(btnReset);
        Controls.Add(lKet);
        Controls.Add(txtKetQua);
        Controls.Add(btnThoat);
        Controls.Add(btnThucHien);
        Controls.Add(grpSort);
        Controls.Add(grpTim);
        Controls.Add(grpXoa);
        Controls.Add(grpThem);
        Controls.Add(grpThongKe);
        Controls.Add(grpMaxMin);
        Controls.Add(grpThay);

        FormClosing += Form_FormClosing;

        grpSort.ResumeLayout(false);
        grpSort.PerformLayout();
        grpTim.ResumeLayout(false);
        grpTim.PerformLayout();
        grpXoa.ResumeLayout(false);
        grpXoa.PerformLayout();
        grpThem.ResumeLayout(false);
        grpThem.PerformLayout();
        grpThongKe.ResumeLayout(false);
        grpThongKe.PerformLayout();
        grpMaxMin.ResumeLayout(false);
        grpMaxMin.PerformLayout();
        grpThay.ResumeLayout(false);
        grpThay.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
}