using System;

namespace WinForms.TH4d;

public class MangSoNguyen
{
    private int[] _a = Array.Empty<int>();

    public int[] A => _a;

    public void Nhap(string input)
    {
        string[] parts = input.Split(new[] { ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

        if (parts.Length == 0)
            throw new FormatException("Mảng chưa có phần tử.");

        int[] mang = new int[parts.Length];

        for (int i = 0; i < parts.Length; i++)
        {
            if (!int.TryParse(parts[i], out mang[i]))
                throw new FormatException("Mảng chỉ được chứa số nguyên.");
        }

        _a = mang;
    }

    public string Xuat() => string.Join(" ", _a);

    public void SapXepTang()
    {
        for (int i = 0; i < _a.Length - 1; i++)
            for (int j = i + 1; j < _a.Length; j++)
                if (_a[i] > _a[j])
                {
                    int temp = _a[i]; _a[i] = _a[j]; _a[j] = temp;
                }
    }

    public void SapXepGiam()
    {
        for (int i = 0; i < _a.Length - 1; i++)
            for (int j = i + 1; j < _a.Length; j++)
                if (_a[i] < _a[j])
                {
                    int temp = _a[i]; _a[i] = _a[j]; _a[j] = temp;
                }
    }

    public int TimGiaTri(int value)
    {
        for (int i = 0; i < _a.Length; i++)
            if (_a[i] == value) return i;
        return -1;
    }

    public int TimViTri(int position)
    {
        KiemTraViTri(position);
        return _a[position];
    }

    public void Them(int value, int position)
    {
        if (position < 0 || position > _a.Length)
            throw new IndexOutOfRangeException("Vị trí thêm không hợp lệ.");

        int[] b = new int[_a.Length + 1];

        for (int i = 0; i < position; i++) b[i] = _a[i];
        b[position] = value;
        for (int i = position; i < _a.Length; i++) b[i + 1] = _a[i];

        _a = b;
    }

    public bool XoaGiaTri(int value)
    {
        int position = TimGiaTri(value);
        if (position == -1) return false;
        XoaViTri(position);
        return true;
    }

    public void XoaViTri(int position)
    {
        KiemTraViTri(position);

        int[] b = new int[_a.Length - 1];
        for (int i = 0; i < position; i++) b[i] = _a[i];
        for (int i = position + 1; i < _a.Length; i++) b[i - 1] = _a[i];
        _a = b;
    }

    public int Tong()
    {
        int s = 0;
        foreach (int x in _a) s += x;
        return s;
    }

    public int TongChan()
    {
        int s = 0;
        foreach (int x in _a) if (x % 2 == 0) s += x;
        return s;
    }

    public int TongLe()
    {
        int s = 0;
        foreach (int x in _a) if (x % 2 != 0) s += x;
        return s;
    }

    public int Max()
    {
        if (_a.Length == 0) throw new InvalidOperationException("Mảng rỗng.");
        int max = _a[0];
        for (int i = 1; i < _a.Length; i++) if (_a[i] > max) max = _a[i];
        return max;
    }

    public int Min()
    {
        if (_a.Length == 0) throw new InvalidOperationException("Mảng rỗng.");
        int min = _a[0];
        for (int i = 1; i < _a.Length; i++) if (_a[i] < min) min = _a[i];
        return min;
    }

    public bool ThayGiaTri(int oldValue, int newValue)
    {
        for (int i = 0; i < _a.Length; i++)
            if (_a[i] == oldValue)
            {
                _a[i] = newValue;
                return true;
            }
        return false;
    }

    public void ThayViTri(int position, int newValue)
    {
        KiemTraViTri(position);
        _a[position] = newValue;
    }

    private void KiemTraViTri(int position)
    {
        if (position < 0 || position >= _a.Length)
            throw new IndexOutOfRangeException("Vị trí không hợp lệ.");
    }
}
