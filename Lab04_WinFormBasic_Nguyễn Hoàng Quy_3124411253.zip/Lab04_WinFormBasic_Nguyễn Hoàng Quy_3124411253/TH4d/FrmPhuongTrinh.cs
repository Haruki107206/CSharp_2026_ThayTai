using System;
using System.Windows.Forms;

namespace WinForms.TH4d;

public partial class FrmPhuongTrinh : Form
{
    public FrmPhuongTrinh()
    {
        InitializeComponent();
        rdoBacNhat.Checked = true;
        txtA.TextChanged += InputChanged;
        txtB.TextChanged += InputChanged;
        txtC.TextChanged += InputChanged;
        CapNhatGiaoDien();
    }

    private void CapNhatGiaoDien()
    {
        bool bacHai = rdoBacHai.Checked;
        txtC.Enabled = bacHai;
        lc.Enabled = bacHai;
        txtKetQua.Clear();
        errorProvider1.Clear();
        btnGiai.Enabled = false;
    }

    private void rdo_CheckedChanged(object? sender, EventArgs e) => CapNhatGiaoDien();

    private void InputChanged(object? sender, EventArgs e) => KiemTraDuLieu();

    private void KiemTraDuLieu()
    {
        bool hopLeA = double.TryParse(txtA.Text, out _);
        bool hopLeB = double.TryParse(txtB.Text, out _);
        bool hopLeC = !rdoBacHai.Checked || double.TryParse(txtC.Text, out _);

        errorProvider1.SetError(txtA, hopLeA ? "" : "Nhập số hợp lệ.");
        errorProvider1.SetError(txtB, hopLeB ? "" : "Nhập số hợp lệ.");
        errorProvider1.SetError(txtC, hopLeC ? "" : "Nhập số hợp lệ.");

        btnGiai.Enabled = hopLeA && hopLeB && hopLeC;
    }

    private void btnGiai_Click(object? sender, EventArgs e)
    {
        if (!double.TryParse(txtA.Text, out double a) || !double.TryParse(txtB.Text, out double b))
        {
            MessageBox.Show("a và b phải là số.");
            return;
        }

        double c = 0;
        if (rdoBacHai.Checked && !double.TryParse(txtC.Text, out c))
        {
            MessageBox.Show("c phải là số.");
            return;
        }

        PhuongTrinhBacHai pt = new PhuongTrinhBacHai(a, b, c);
        txtKetQua.Text = rdoBacNhat.Checked ? pt.GiaiBacNhat() : pt.GiaiBacHai();
        btnGiai.Enabled = false;
    }

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
