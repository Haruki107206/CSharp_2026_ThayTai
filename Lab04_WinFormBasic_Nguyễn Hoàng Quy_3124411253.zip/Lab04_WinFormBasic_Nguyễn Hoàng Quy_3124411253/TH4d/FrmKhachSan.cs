using System;
using System.Windows.Forms;

namespace WinForms.TH4d;

public partial class FrmKhachSan : Form
{
    private decimal _tongTien;
    private int _tongKhach;
    private decimal _tienLanNay;

    public FrmKhachSan()
    {
        InitializeComponent();
        Load += Form_Load;
        txtHoTen.TextChanged += InputsChanged;
        txtDiaChi.TextChanged += InputsChanged;
        txtSoNgay.TextChanged += InputsChanged;
        rdoDon.CheckedChanged += InputsChanged;
        rdoDoi.CheckedChanged += InputsChanged;
        rdoBa.CheckedChanged += InputsChanged;
    }

    private void Form_Load(object? sender, EventArgs e)
    {
        txtHoTen.Focus();
        btnTongKet.Enabled = false;
        btnNhapMoi.Enabled = false;
        btnThanhToan.Enabled = false;
    }

    private static void NumberKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
    }

    private bool HopLe()
    {
        if (string.IsNullOrWhiteSpace(txtHoTen.Text)) { MessageBox.Show("Tên khách không được để trống."); return false; }
        if (string.IsNullOrWhiteSpace(txtDiaChi.Text)) { MessageBox.Show("Địa chỉ không được để trống."); return false; }
        if (!int.TryParse(txtSoNgay.Text, out int ngay) || ngay <= 0) { MessageBox.Show("Số ngày ở phải là số nguyên dương."); return false; }
        if (!(rdoDon.Checked || rdoDoi.Checked || rdoBa.Checked)) { MessageBox.Show("Hãy chọn loại phòng."); return false; }
        return true;
    }

    private decimal GiaPhong()
    {
        if (rdoDon.Checked) return 300000;
        if (rdoDoi.Checked) return 350000;
        return 400000;
    }

    private decimal TinhTien()
    {
        int ngay = int.Parse(txtSoNgay.Text);
        decimal tien = GiaPhong() * ngay;

        if (chkTivi.Checked) tien += 10000;
        if (chkInternet.Checked) tien += 10000;
        if (chkMayNuocNong.Checked) tien += 10000;
        if (chkKaraoke.Checked) tien += 50000;
        if (chkAnSang.Checked) tien += 15000 * ngay;

        return tien;
    }

    private void CapNhatTrangThai()
    {
        bool hopLe = !string.IsNullOrWhiteSpace(txtHoTen.Text) &&
                     !string.IsNullOrWhiteSpace(txtDiaChi.Text) &&
                     int.TryParse(txtSoNgay.Text, out int ngay) && ngay > 0 &&
                     (rdoDon.Checked || rdoDoi.Checked || rdoBa.Checked);

        btnThanhToan.Enabled = hopLe;
    }

    private void btnThanhToan_Click(object? sender, EventArgs e)
    {
        if (!HopLe()) return;

        _tienLanNay = TinhTien();
        txtThanhTien.Text = _tienLanNay.ToString("N0") + " VND";

        _tongTien += _tienLanNay;
        _tongKhach++;

        btnNhapMoi.Enabled = true;
        btnTongKet.Enabled = true;
        btnThanhToan.Enabled = false;
    }

    private void btnNhapMoi_Click(object? sender, EventArgs e)
    {
        ResetInput();
        btnNhapMoi.Enabled = false;
        btnThanhToan.Enabled = false;
    }

    private void btnTongKet_Click(object? sender, EventArgs e)
    {
        txtTongLuot.Text = _tongKhach.ToString();
        txtTongNgayTien.Text = _tongTien.ToString("N0") + " VND";

        _tongKhach = 0;
        _tongTien = 0;
        btnTongKet.Enabled = false;
    }

    private void ResetInput()
    {
        txtHoTen.Clear(); txtDiaChi.Clear(); txtSoNgay.Clear();
        rdoDon.Checked = false; rdoDoi.Checked = false; rdoBa.Checked = false;
        chkTivi.Checked = false; chkInternet.Checked = false; chkMayNuocNong.Checked = false; chkKaraoke.Checked = false; chkAnSang.Checked = false;
        txtThanhTien.Clear();
        _tienLanNay = 0;
        txtHoTen.Focus();
    }

    private void InputsChanged(object? sender, EventArgs e) => CapNhatTrangThai();

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
