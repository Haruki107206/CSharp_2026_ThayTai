using System;
using System.Windows.Forms;

namespace WinForms.TH4d;

public partial class FrmCafeSinhVien : Form
{
    private int _tongKhach;
    private decimal _tongTien;
    private decimal _tienLanNay;

    public FrmCafeSinhVien()
    {
        InitializeComponent();
        Load += Form_Load;
        txtTenKhach.TextChanged += InputChanged;
        txtSoKhach.TextChanged += InputChanged;
        rdoDen.CheckedChanged += InputChanged;
        rdoDa.CheckedChanged += InputChanged;
        rdoSua.CheckedChanged += InputChanged;
        rdoSuaDa.CheckedChanged += InputChanged;
        rdoKem.CheckedChanged += InputChanged;
    }

    private void Form_Load(object? sender, EventArgs e)
    {
        txtTenKhach.Focus();
        btnTinhTien.Enabled = false;
        btnNhapLai.Enabled = false;
        btnThanhToan.Enabled = false;
    }

    private static void NumberKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
    }

    private bool DuThongTin()
    {
        if (string.IsNullOrWhiteSpace(txtTenKhach.Text))
        {
            MessageBox.Show("Tên khách hàng không được để trống."); txtTenKhach.Focus(); return false;
        }
        if (!int.TryParse(txtSoKhach.Text, out int soKhach) || soKhach <= 0)
        {
            MessageBox.Show("Số khách hàng phải là số nguyên dương."); txtSoKhach.Focus(); return false;
        }
        if (!(rdoDen.Checked || rdoDa.Checked || rdoSua.Checked || rdoSuaDa.Checked || rdoKem.Checked))
        {
            MessageBox.Show("Hãy chọn loại cafe."); return false;
        }
        return true;
    }

    private decimal GiaCafe()
    {
        if (rdoDen.Checked) return 20000;
        if (rdoDa.Checked || rdoSua.Checked) return 25000;
        if (rdoSuaDa.Checked) return 30000;
        return 35000;
    }

    private decimal GiaAn()
    {
        decimal s = 0;
        if (chkBanhTrung.Checked) s += 15000;
        if (chkBanhCa.Checked) s += 15000;
        if (chkMyTom.Checked) s += 20000;
        if (chkMyXao.Checked) s += 30000;
        if (chkMyCay.Checked) s += 50000;
        return s;
    }

    private void InputChanged(object? sender, EventArgs e)
    {
        bool coCafe = rdoDen.Checked || rdoDa.Checked || rdoSua.Checked || rdoSuaDa.Checked || rdoKem.Checked;
        bool soKhachHopLe = int.TryParse(txtSoKhach.Text, out int soKhach) && soKhach > 0;
        btnTinhTien.Enabled = !string.IsNullOrWhiteSpace(txtTenKhach.Text) && soKhachHopLe && coCafe;
    }

    private void btnTinhTien_Click(object? sender, EventArgs e)
    {
        if (!DuThongTin()) return;

        int soKhach = int.Parse(txtSoKhach.Text);
        decimal donGia = GiaCafe() + GiaAn();
        _tienLanNay = donGia * soKhach;

        if (chkSinhVien.Checked)
            _tienLanNay *= 0.8m;

        MessageBox.Show(
            "Khách hàng: " + txtTenKhach.Text + "\n" +
            "Số khách: " + soKhach + "\n" +
            "Tiền phải trả: " + _tienLanNay.ToString("N0") + " đ",
            "Tính tiền");

        btnNhapLai.Enabled = true;
        btnThanhToan.Enabled = true;
    }

    private void btnNhapLai_Click(object? sender, EventArgs e)
    {
        ResetNhap();
        btnNhapLai.Enabled = false;
        btnThanhToan.Enabled = false;
        btnTinhTien.Enabled = false;
    }

    private void btnThanhToan_Click(object? sender, EventArgs e)
    {
        if (_tienLanNay <= 0) return;

        _tongKhach += int.Parse(txtSoKhach.Text);
        _tongTien += _tienLanNay;

        txtTongKhach.Text = _tongKhach.ToString();
        txtTongTien.Text = _tongTien.ToString("N0") + " đ";

        ResetNhap();
        btnThanhToan.Enabled = false;
        btnNhapLai.Enabled = false;
        btnTinhTien.Enabled = false;
    }

    private void ResetNhap()
    {
        txtTenKhach.Clear(); txtSoKhach.Clear(); chkSinhVien.Checked = false;
        rdoDen.Checked = false; rdoDa.Checked = false; rdoSua.Checked = false; rdoSuaDa.Checked = false; rdoKem.Checked = false;
        chkBanhTrung.Checked = false; chkBanhCa.Checked = false; chkMyTom.Checked = false; chkMyXao.Checked = false; chkMyCay.Checked = false;
        _tienLanNay = 0; txtTenKhach.Focus();
    }

    private void btnThoat_Click(object? sender, EventArgs e) => Close();

    private void Form_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            e.Cancel = true;
    }
}
