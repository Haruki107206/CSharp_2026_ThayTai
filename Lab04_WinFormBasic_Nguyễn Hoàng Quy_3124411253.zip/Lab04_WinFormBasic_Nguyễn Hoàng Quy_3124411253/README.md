# WinForms - TH4c / TH4d

Project WinForms C# theo hai tài liệu thực hành 04c và 04d.

## Cấu trúc
- `TH4c`: các bài phép tính, đăng ký tài khoản, UCLN/BCNN, dãy số, đọc số, bán vé rạp, máy tính bỏ túi.
- `TH4d`: phương trình bậc 1/2, mảng số nguyên, Cafe Sinh Viên, Khách sạn Thanh Thanh.

## Giao diện
Các Designer.cs đã được căn chỉnh lại theo hình minh họa trong PDF: tiêu đề, label, textbox, radio button, checkbox, groupbox, nút chức năng và vùng kết quả được bố trí theo cùng bố cục, tránh chồng lấn và mất ký tự đầu.

## Chạy bài
Mở `WinForms.sln`. Để đổi bài chạy, sửa dòng `Application.Run(...)` trong `Program.cs`.

Ví dụ:
`Application.Run(new WinForms.TH4c.FrmDaySo());`

## Lưu ý
`Designer.cs` là phần giao diện; phần xử lý nằm trong các file `.cs` tương ứng. Project dùng .NET 10 Windows Forms.
