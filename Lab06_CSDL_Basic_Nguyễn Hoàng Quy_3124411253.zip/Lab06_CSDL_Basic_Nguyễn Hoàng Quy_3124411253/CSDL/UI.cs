namespace CSDL;

/// <summary>Các hàm nhỏ giúp dựng giao diện bằng code cho gọn (không ảnh hưởng phần xử lý CSDL).</summary>
internal static class UI
{
    public static readonly Font F = new Font("Segoe UI", 10f);

    public static void Setup(Form f, string text, int w, int h)
    {
        f.Text = text; f.Font = F; f.ClientSize = new Size(w, h);
        f.StartPosition = FormStartPosition.CenterScreen;
    }

    public static Label Lbl(Control p, string t, int x, int y, int w = 100, int h = 24)
    {
        var c = new Label { Text = t, Left = x, Top = y, Width = w, Height = h, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
        p.Controls.Add(c); return c;
    }

    public static TextBox Txt(Control p, int x, int y, int w = 200)
    {
        var c = new TextBox { Left = x, Top = y, Width = w }; p.Controls.Add(c); return c;
    }

    public static MaskedTextBox Mask(Control p, int x, int y, int w = 200)
    {
        var m = new MaskedTextBox { Left = x, Top = y, Width = w, Culture = System.Globalization.CultureInfo.InvariantCulture, Mask = "00/00/0000" };
        p.Controls.Add(m); return m;
    }

    public static Button Btn(Control p, string t, int x, int y, int w, int h, EventHandler click = null)
    {
        var b = new Button { Text = t, Left = x, Top = y, Width = w, Height = h, UseVisualStyleBackColor = true };
        if (click != null) b.Click += click;
        p.Controls.Add(b); return b;
    }

    public static ComboBox Cbo(Control p, int x, int y, int w = 200)
    {
        var c = new ComboBox { Left = x, Top = y, Width = w, DropDownStyle = ComboBoxStyle.DropDownList };
        p.Controls.Add(c); return c;
    }

    public static GroupBox Grp(Control p, string t, int x, int y, int w, int h)
    {
        var c = new GroupBox { Text = t, Left = x, Top = y, Width = w, Height = h }; p.Controls.Add(c); return c;
    }

    public static ListView LV(Control p, int x, int y, int w, int h, params (string name, int width)[] cols)
    {
        var l = new ListView { Left = x, Top = y, Width = w, Height = h, View = View.Details, FullRowSelect = true, GridLines = true, HideSelection = false };
        foreach (var c in cols) l.Columns.Add(c.name, c.width);
        p.Controls.Add(l); return l;
    }

    public static void Info(string m) => MessageBox.Show(m, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
    public static void Warn(string m) => MessageBox.Show(m, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    public static bool Ask(string m) => MessageBox.Show(m, "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
}
