-- ===========================================================
-- CSDL QLCuaHang (Lab 06b - Bài tập về nhà):
-- SANPHAM, HOADON, CHITIET_HOADON, TONKHO
-- ===========================================================
IF DB_ID(N'QLCuaHang') IS NULL
    CREATE DATABASE QLCuaHang;
GO
USE QLCuaHang;
GO

IF OBJECT_ID(N'dbo.SANPHAM', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SANPHAM
    (
        MaSP  INT IDENTITY(1,1) PRIMARY KEY,      -- tự động tăng
        TenSP NVARCHAR(100) NOT NULL
    );
    INSERT INTO dbo.SANPHAM(TenSP) VALUES (N'Trà xanh'), (N'Mức dâu'), (N'Cafe');
END
GO

IF OBJECT_ID(N'dbo.HOADON', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HOADON
    (
        MaHD               INT IDENTITY(1,1) PRIMARY KEY,   -- tự động tăng
        NgayTao            DATETIME NOT NULL DEFAULT GETDATE(),
        TinhTrangThanhToan BIT      NOT NULL DEFAULT 0      -- 0: chưa thanh toán, 1: đã thanh toán
    );
END
GO

IF OBJECT_ID(N'dbo.CHITIET_HOADON', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CHITIET_HOADON
    (
        MaHD    INT NOT NULL REFERENCES dbo.HOADON(MaHD),
        MaSP    INT NOT NULL REFERENCES dbo.SANPHAM(MaSP),
        SoLuong INT NOT NULL CHECK (SoLuong > 0),
        PRIMARY KEY (MaHD, MaSP)
    );
END
GO

IF OBJECT_ID(N'dbo.TONKHO', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TONKHO
    (
        MaSP    INT  NOT NULL REFERENCES dbo.SANPHAM(MaSP),
        NgayTon DATE NOT NULL,
        SLDau   INT  NOT NULL,     -- số lượng tồn đầu ngày
        SLNhap  INT  NOT NULL,     -- tổng số lượng nhập trong ngày
        SLBan   INT  NOT NULL,     -- tổng số lượng bán trong ngày
        PRIMARY KEY (MaSP, NgayTon)
    );
    INSERT INTO dbo.TONKHO(MaSP, NgayTon, SLDau, SLNhap, SLBan) VALUES
        (1, '2016-10-29', 50, 0, 0),
        (2, '2016-10-29', 50, 0, 0),
        (3, '2016-10-29', 50, 0, 0);
END
GO
