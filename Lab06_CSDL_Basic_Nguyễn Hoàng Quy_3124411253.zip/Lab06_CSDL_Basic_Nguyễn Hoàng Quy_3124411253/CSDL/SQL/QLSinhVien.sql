-- ===========================================================
-- CSDL QLSinhVien (Lab 06): Khoa, Lop, SinhVien, MonHoc, Diem
-- Có thể chạy thẳng trong SQL Server Management Studio (SSMS).
-- Chương trình C# cũng tự chạy script này khi khởi động.
-- ===========================================================
IF DB_ID(N'QLSinhVien') IS NULL
    CREATE DATABASE QLSinhVien;
GO
USE QLSinhVien;
GO

IF OBJECT_ID(N'dbo.Khoa', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Khoa
    (
        MaKhoa  VARCHAR(10)   NOT NULL PRIMARY KEY,
        TenKhoa NVARCHAR(100) NOT NULL
    );
    INSERT INTO dbo.Khoa(MaKhoa, TenKhoa) VALUES
        ('CNTT', N'Công nghệ thông tin'),
        ('KT',   N'Kế toán'),
        ('HH',   N'Hóa học'),
        ('QTKD', N'Quản trị kinh doanh'),
        ('NN',   N'Ngoại ngữ');
END
GO

IF OBJECT_ID(N'dbo.Lop', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Lop
    (
        MaLop  VARCHAR(10)   NOT NULL PRIMARY KEY,
        TenLop NVARCHAR(100) NOT NULL,
        MaKhoa VARCHAR(10)   NOT NULL REFERENCES dbo.Khoa(MaKhoa)
    );
    INSERT INTO dbo.Lop(MaLop, TenLop, MaKhoa) VALUES
        ('05DHKT2', N'Kế toán ngân hàng khóa 05',     'KT'),
        ('05DHTH1', N'Công nghệ phần mềm khóa 05',    'CNTT'),
        ('05DHTH2', N'Lập trình mạng khóa 05',        'CNTT'),
        ('06DHHH1', N'Hóa phân tích khóa 06',         'HH'),
        ('06DHKT1', N'Thuế doanh nghiệp khóa 06',     'KT'),
        ('06DHTH1', N'Công nghệ phần mềm khóa 06',    'CNTT');
END
GO

IF OBJECT_ID(N'dbo.SinhVien', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SinhVien
    (
        MaSinhVien VARCHAR(15)   NOT NULL PRIMARY KEY,
        HoTen      NVARCHAR(100) NOT NULL,
        NgaySinh   DATE          NOT NULL,
        MaLop      VARCHAR(10)   NOT NULL REFERENCES dbo.Lop(MaLop)
    );
    INSERT INTO dbo.SinhVien(MaSinhVien, HoTen, NgaySinh, MaLop) VALUES
        ('SV001', N'Trần Thanh Tùng',   '1993-10-12', '05DHTH1'),
        ('SV002', N'Nguyễn Thanh Bình', '1993-04-02', '05DHTH1'),
        ('SV003', N'Nguyễn Đạt Nhân',   '1992-03-15', '05DHTH2'),
        ('SV004', N'Nguyễn Gia Bảo',    '1993-05-11', '05DHKT2'),
        ('SV005', N'Nguyễn Thanh Lan',  '1993-06-12', '06DHKT1'),
        ('SV006', N'Lâm Văn Tuấn',      '1993-08-03', '06DHTH1');
END
GO

IF OBJECT_ID(N'dbo.MonHoc', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MonHoc
    (
        MaMonHoc  VARCHAR(10)   NOT NULL PRIMARY KEY,
        TenMonHoc NVARCHAR(100) NOT NULL
    );
    INSERT INTO dbo.MonHoc(MaMonHoc, TenMonHoc) VALUES
        ('MH01', N'Toán Cao cấp'),
        ('MH02', N'Mac - Lênin'),
        ('MH03', N'Tin học đại cương'),
        ('MH04', N'Vật lý đại cương'),
        ('MH05', N'Tiếng Anh cơ bản');
END
GO

IF OBJECT_ID(N'dbo.Diem', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Diem
    (
        MaSinhVien VARCHAR(15) NOT NULL REFERENCES dbo.SinhVien(MaSinhVien),
        MaMonHoc   VARCHAR(10) NOT NULL REFERENCES dbo.MonHoc(MaMonHoc),
        Diem       FLOAT       NOT NULL,
        PRIMARY KEY (MaSinhVien, MaMonHoc)
    );
    INSERT INTO dbo.Diem(MaSinhVien, MaMonHoc, Diem) VALUES
        ('SV001','MH01',4), ('SV001','MH02',7),
        ('SV002','MH01',6), ('SV002','MH02',3), ('SV002','MH03',5),
        ('SV003','MH01',9), ('SV003','MH02',10),('SV003','MH03',9),
        ('SV004','MH01',3), ('SV004','MH02',6),
        ('SV005','MH01',5), ('SV005','MH03',7),
        ('SV006','MH02',8), ('SV006','MH03',8);
END
GO
