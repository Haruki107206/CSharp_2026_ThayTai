using System.Data;
using System.Data.SqlClient;
using System.Text;
namespace CSDL;

/// <summary>
/// Chứa chuỗi kết nối + một vài hàm dùng chung cho các form.
/// *** ĐỔI "SERVER" cho đúng máy bạn: "." | ".\SQLEXPRESS" | "(localdb)\MSSQLLocalDB" | "TÊN-MÁY\SQL2012" ***
/// </summary>
internal static class KetNoi
{
    public const string SERVER = "HUNGTRAN";

    // Cách 1 trong đề: đăng nhập bằng quyền Windows (Integrated Security = True).
    // Nếu dùng SQL Server Authentication (cách 2) thì thay bằng:
    //   "Data Source=..;Initial Catalog=..;User ID=sa;Password=..."
    static string TaoChuoi(string tenCSDL) =>
        "Data Source=" + SERVER + ";Initial Catalog=" + tenCSDL + ";Integrated Security=True;TrustServerCertificate=True";

    public static string ChuoiQLSinhVien => TaoChuoi("QLSinhVien");
    public static string ChuoiQLCuaHang => TaoChuoi("QLCuaHang");

    /// <summary>Chạy file script trong thư mục SQL (các lệnh cách nhau bởi dòng GO) để tạo CSDL + bảng + dữ liệu mẫu nếu chưa có.</summary>
    public static void TaoCSDL(string tenFileSql)
    {
        string duongDan = Path.Combine(AppContext.BaseDirectory, "SQL", tenFileSql);
        string[] cacDong = File.ReadAllLines(duongDan);

        // kết nối vào master vì lúc đầu CSDL có thể chưa tồn tại
        using (SqlConnection conn = new SqlConnection(TaoChuoi("master")))
        {
            conn.Open();
            StringBuilder lenh = new StringBuilder();
            foreach (string dong in cacDong)
            {
                if (dong.Trim().ToUpper() == "GO")     // gặp GO -> chạy khối lệnh đã gom
                {
                    ChayKhoiLenh(conn, lenh.ToString());
                    lenh.Clear();
                }
                else lenh.AppendLine(dong);
            }
            ChayKhoiLenh(conn, lenh.ToString());
        }
    }

    static void ChayKhoiLenh(SqlConnection conn, string sql)
    {
        if (sql.Trim() == "") return;
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Kiểm tra bằng SqlDataReader: câu SELECT có trả về ÍT NHẤT 1 dòng hay không.
    /// Dùng để kiểm tra khóa chính (trùng?) và khóa ngoại (tồn tại?).
    /// </summary>
    public static bool CoDuLieu(SqlConnection conn, string selectString, params SqlParameter[] cacThamSo)
    {
        try
        {
            if (conn.State == ConnectionState.Closed) conn.Open();
            SqlCommand cmd = new SqlCommand(selectString, conn);
            cmd.Parameters.AddRange(cacThamSo);
            SqlDataReader rd = cmd.ExecuteReader();
            bool co = rd.HasRows;
            rd.Close();
            return co;
        }
        finally
        {
            if (conn.State == ConnectionState.Open) conn.Close();
        }
    }

    /// <summary>Dùng SqlDataReader đọc 1 cột của câu SELECT rồi đưa vào ComboBox.</summary>
    public static void NapComboBox(SqlConnection conn, ComboBox cbo, string selectString, string tenCot)
    {
        try
        {
            if (conn.State == ConnectionState.Closed) conn.Open();
            SqlCommand cmd = new SqlCommand(selectString, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            cbo.Items.Clear();
            while (rd.Read())
            {
                cbo.Items.Add(rd[tenCot].ToString());
            }
            rd.Close();
        }
        finally
        {
            if (conn.State == ConnectionState.Open) conn.Close();
        }
    }
}
