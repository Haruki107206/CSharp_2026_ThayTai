using System.Data;
using System.Data.SqlClient;
using System.Globalization;
namespace CSDL.TH6b;

// TH6b – Bài tập tại lớp 2: Cập nhật điểm (ComboBox Sinh viên, Môn học)
public class frmDiem_Combo : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    ComboBox cboSinhVien, cboMonHoc; TextBox txtDiem;

    public frmDiem_Combo()
    {
        UI.Setup(this, "frmDiem_combo", 380, 195);
        UI.Lbl(this, "Sinh viên", 15, 15, 70);  cboSinhVien = UI.Cbo(this, 90, 13, 270);
        UI.Lbl(this, "Môn học", 15, 50, 70);    cboMonHoc = UI.Cbo(this, 90, 48, 270);
        UI.Lbl(this, "Điểm", 15, 85, 70);       txtDiem = UI.Txt(this, 90, 83, 270);
        UI.Btn(this, "Thêm", 25, 135, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 135, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 135, 100, 36, btnSua_Click);
        Load += frmDiem_Combo_Load;
    }

    private void frmDiem_Combo_Load(object sender, EventArgs e)
    {
        try
        {
            KetNoi.NapComboBox(connsql, cboSinhVien, "SELECT MaSinhVien FROM SinhVien ORDER BY MaSinhVien", "MaSinhVien");
            KetNoi.NapComboBox(connsql, cboMonHoc, "SELECT MaMonHoc FROM MonHoc ORDER BY MaMonHoc", "MaMonHoc");
        }
        catch (Exception ex) { UI.Warn("Không nạp được dữ liệu cho ComboBox: " + ex.Message); }
    }

    // Kiểm tra dữ liệu nhập cho Thêm / Sửa: đủ thông tin, Điểm là số trong khoảng 0..10
    private bool KiemTraNhap(out double diem)
    {
        diem = 0;
        if (cboSinhVien.SelectedIndex < 0 || cboMonHoc.SelectedIndex < 0 || txtDiem.Text.Trim() == "")
        {
            UI.Warn("Tất cả thông tin phải được nhập dữ liệu!");
            return false;
        }
        if (!double.TryParse(txtDiem.Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out diem)
            || diem < 0 || diem > 10)
        {
            UI.Warn("Điểm phải là số trong khoảng từ 0 đến 10!");
            txtDiem.Focus();
            return false;
        }
        return true;
    }

    // Câu điều kiện tìm đúng 1 dòng điểm theo khóa chính (Mã SV + Mã môn học)
    private const string TIM_DIEM = "SELECT * FROM Diem WHERE MaSinhVien=@sv AND MaMonHoc=@mh";

    private void btnThem_Click(object sender, EventArgs e)
    {
        if (!KiemTraNhap(out double diem)) return;
        string maSV = cboSinhVien.SelectedItem.ToString(), maMH = cboMonHoc.SelectedItem.ToString();
        try
        {
            // Khóa ngoại: sinh viên và môn học phải tồn tại trong CSDL
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM SinhVien WHERE MaSinhVien=@sv", new SqlParameter("@sv", maSV)))
            { UI.Warn("Mã sinh viên không tồn tại trong CSDL!"); return; }
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM MonHoc WHERE MaMonHoc=@mh", new SqlParameter("@mh", maMH)))
            { UI.Warn("Mã môn học không tồn tại trong CSDL!"); return; }
            // Khóa chính: (Mã SV, Mã môn học) không được trùng
            if (KetNoi.CoDuLieu(connsql, TIM_DIEM, new SqlParameter("@sv", maSV), new SqlParameter("@mh", maMH)))
            { UI.Warn("Sinh viên này đã có điểm môn học này (trùng khóa chính)!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Diem(MaSinhVien, MaMonHoc, Diem) VALUES(@sv, @mh, @d)", connsql);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            cmd.Parameters.AddWithValue("@d", diem);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa: chỉ cần chọn Sinh viên + Môn học; dòng điểm phải tồn tại
    private void btnXoa_Click(object sender, EventArgs e)
    {
        if (cboSinhVien.SelectedIndex < 0 || cboMonHoc.SelectedIndex < 0)
        { UI.Warn("Hãy chọn Sinh viên và Môn học!"); return; }
        string maSV = cboSinhVien.SelectedItem.ToString(), maMH = cboMonHoc.SelectedItem.ToString();
        try
        {
            if (!KetNoi.CoDuLieu(connsql, TIM_DIEM, new SqlParameter("@sv", maSV), new SqlParameter("@mh", maMH)))
            { UI.Warn("Không có dòng điểm tương ứng để xóa!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Diem WHERE MaSinhVien=@sv AND MaMonHoc=@mh", connsql);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnSua_Click(object sender, EventArgs e)
    {
        if (!KiemTraNhap(out double diem)) return;
        string maSV = cboSinhVien.SelectedItem.ToString(), maMH = cboMonHoc.SelectedItem.ToString();
        try
        {
            if (!KetNoi.CoDuLieu(connsql, TIM_DIEM, new SqlParameter("@sv", maSV), new SqlParameter("@mh", maMH)))
            { UI.Warn("Không có dòng điểm tương ứng để sửa!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Diem SET Diem=@d WHERE MaSinhVien=@sv AND MaMonHoc=@mh", connsql);
            cmd.Parameters.AddWithValue("@d", diem);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
