using System.Data;
using System.Data.SqlClient;
using System.Globalization;
namespace CSDL.TH6b;

// TH6b – Bài tập tại lớp 1: Sinh viên (ComboBox Lớp)
public class frmSinhVien_Combo : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    ComboBox cboLop; TextBox txtMaSV, txtHoTen; MaskedTextBox mtbNgaySinh;

    public frmSinhVien_Combo()
    {
        UI.Setup(this, "frmSinhvien_Combo", 380, 230);
        UI.Lbl(this, "Lớp", 15, 15, 75);        cboLop = UI.Cbo(this, 95, 13, 265);
        UI.Lbl(this, "Mã sv", 15, 50, 75);      txtMaSV = UI.Txt(this, 95, 48, 265);
        UI.Lbl(this, "Họ tên", 15, 85, 75);     txtHoTen = UI.Txt(this, 95, 83, 265);
        UI.Lbl(this, "Ngày sinh", 15, 120, 75); mtbNgaySinh = UI.Mask(this, 95, 118, 265);
        UI.Btn(this, "Thêm", 25, 170, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 170, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 170, 100, 36, btnSua_Click);
        Load += frmSinhVien_Combo_Load;
    }

    // Hiển thị mã lớp (khóa ngoại) trên ComboBox Lớp
    private void frmSinhVien_Combo_Load(object sender, EventArgs e)
    {
        try
        {
            KetNoi.NapComboBox(connsql, cboLop, "SELECT MaLop FROM Lop ORDER BY MaLop", "MaLop");
            if (cboLop.Items.Count > 0) cboLop.SelectedIndex = 0;
        }
        catch (Exception ex) { UI.Warn("Không nạp được danh sách lớp: " + ex.Message); }
    }

    // Kiểm tra dữ liệu nhập dùng chung cho Thêm và Sửa. Trả về true nếu hợp lệ.
    private bool KiemTraNhap(out DateTime ngaySinh)
    {
        ngaySinh = DateTime.MinValue;
        // 1. Tất cả thông tin phải được nhập
        if (cboLop.SelectedIndex < 0 || txtMaSV.Text.Trim() == "" || txtHoTen.Text.Trim() == ""
            || mtbNgaySinh.Text.Replace("/", "").Trim() == "")
        {
            UI.Warn("Tất cả thông tin phải được nhập dữ liệu!");
            return false;
        }
        // 2. Ngày sinh phải đầy đủ và đúng định dạng dd/MM/yyyy
        if (!mtbNgaySinh.MaskCompleted ||
            !DateTime.TryParseExact(mtbNgaySinh.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out ngaySinh))
        {
            UI.Warn("Ngày sinh không hợp lệ! (định dạng dd/MM/yyyy)");
            return false;
        }
        // 3. Tuổi từ 17 trở lên (chỉ tính theo năm sinh)
        int tuoi = DateTime.Now.Year - ngaySinh.Year;
        if (tuoi < 17)
        {
            UI.Warn("Sinh viên phải từ 17 tuổi trở lên (tính theo năm sinh)!\nTuổi tính được: " + tuoi);
            return false;
        }
        return true;
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        if (!KiemTraNhap(out DateTime ngaySinh)) return;
        string maLop = cboLop.SelectedItem.ToString(), maSV = txtMaSV.Text.Trim(), hoTen = txtHoTen.Text.Trim();
        try
        {
            // 4. Kiểm tra khóa chính: Mã sinh viên không được trùng
            if (KetNoi.CoDuLieu(connsql, "SELECT * FROM SinhVien WHERE MaSinhVien=@ma", new SqlParameter("@ma", maSV)))
            { UI.Warn("Trùng mã sinh viên!"); txtMaSV.Focus(); return; }
            // Kiểm tra khóa ngoại: Mã lớp phải tồn tại
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM Lop WHERE MaLop=@lop", new SqlParameter("@lop", maLop)))
            { UI.Warn("Mã lớp không tồn tại!"); return; }

            // 5. Thỏa tất cả yêu cầu -> thêm
            connsql.Open();
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO SinhVien(MaSinhVien, HoTen, NgaySinh, MaLop) VALUES(@ma, @ten, @ns, @lop)", connsql);
            cmd.Parameters.AddWithValue("@ma", maSV);
            cmd.Parameters.AddWithValue("@ten", hoTen);
            cmd.Parameters.AddWithValue("@ns", ngaySinh);
            cmd.Parameters.AddWithValue("@lop", maLop);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa: chỉ cần Mã sinh viên. Kiểm tra khóa chính (phải tồn tại) và khóa ngoại (chưa có điểm)
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string maSV = txtMaSV.Text.Trim();
        if (maSV == "") { UI.Warn("Mã sinh viên không được để trống!"); txtMaSV.Focus(); return; }
        try
        {
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM SinhVien WHERE MaSinhVien=@ma", new SqlParameter("@ma", maSV)))
            { UI.Warn("Mã sinh viên không tồn tại!"); return; }
            if (KetNoi.CoDuLieu(connsql, "SELECT * FROM Diem WHERE MaSinhVien=@ma", new SqlParameter("@ma", maSV)))
            { UI.Warn("Sinh viên này đã có điểm, không thể xóa!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM SinhVien WHERE MaSinhVien=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", maSV);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Sửa: kiểm tra nhập đủ như Thêm; sinh viên phải tồn tại; lớp (khóa ngoại) phải tồn tại
    private void btnSua_Click(object sender, EventArgs e)
    {
        if (!KiemTraNhap(out DateTime ngaySinh)) return;
        string maLop = cboLop.SelectedItem.ToString(), maSV = txtMaSV.Text.Trim(), hoTen = txtHoTen.Text.Trim();
        try
        {
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM SinhVien WHERE MaSinhVien=@ma", new SqlParameter("@ma", maSV)))
            { UI.Warn("Mã sinh viên không tồn tại!"); return; }
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM Lop WHERE MaLop=@lop", new SqlParameter("@lop", maLop)))
            { UI.Warn("Mã lớp không tồn tại!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE SinhVien SET HoTen=@ten, NgaySinh=@ns, MaLop=@lop WHERE MaSinhVien=@ma", connsql);
            cmd.Parameters.AddWithValue("@ten", hoTen);
            cmd.Parameters.AddWithValue("@ns", ngaySinh);
            cmd.Parameters.AddWithValue("@lop", maLop);
            cmd.Parameters.AddWithValue("@ma", maSV);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
