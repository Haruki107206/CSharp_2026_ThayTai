using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài tập về nhà 1: Form chính của CSDL QLCuaHang (có thanh menu)
//   Menu: Tạo tồn kho | Thêm sản phẩm mới | Bán hàng
public class frmCuaHang : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLCuaHang);

    public frmCuaHang()
    {
        UI.Setup(this, "Quản lý cửa hàng", 560, 320);

        var ms = new MenuStrip();
        var mTonKho = new ToolStripMenuItem("&Tạo tồn kho");
        var mThemSP = new ToolStripMenuItem("Thêm &sản phẩm mới");
        var mBanHang = new ToolStripMenuItem("&Bán hàng");
        var mThoat = new ToolStripMenuItem("T&hoát");
        mTonKho.Click += mTonKho_Click;
        mThemSP.Click += (s, e) => { using (var f = new frmThemSanPham()) f.ShowDialog(this); };
        mBanHang.Click += (s, e) => { using (var f = new frmBanHang()) f.ShowDialog(this); };
        mThoat.Click += (s, e) => Close();
        ms.Items.AddRange(new ToolStripItem[] { mTonKho, mThemSP, mBanHang, mThoat });
        MainMenuStrip = ms; Controls.Add(ms);

        var lbl = UI.Lbl(this, "Chọn chức năng trên thanh menu.\r\nLưu ý: mỗi ngày hãy chạy \"Tạo tồn kho\" trước khi bán hàng.", 20, 100, 520, 80);
        lbl.TextAlign = ContentAlignment.MiddleCenter;
    }

    // Tạo dữ liệu tồn kho cho NGÀY HIỆN TẠI của tất cả sản phẩm:
    //   SLDau (hôm nay) = SLDau + SLNhap - SLBan của ngày trước;  SLNhap = 0;  SLBan = 0
    // "Ngày trước" = ngày gần nhất có dữ liệu tồn kho nhỏ hơn hôm nay.
    // Sản phẩm nào đã có dòng tồn kho hôm nay thì bỏ qua => bấm nhiều lần cũng không bị tạo trùng.
    private void mTonKho_Click(object sender, EventArgs e)
    {
        string insertString =
            "INSERT INTO TONKHO(MaSP, NgayTon, SLDau, SLNhap, SLBan) " +
            "SELECT t.MaSP, @homnay, t.SLDau + t.SLNhap - t.SLBan, 0, 0 " +
            "FROM TONKHO t " +
            "WHERE t.NgayTon = (SELECT MAX(NgayTon) FROM TONKHO WHERE MaSP = t.MaSP AND NgayTon < @homnay) " +
            "AND NOT EXISTS (SELECT 1 FROM TONKHO x WHERE x.MaSP = t.MaSP AND x.NgayTon = @homnay)";
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand(insertString, connsql);
            cmd.Parameters.AddWithValue("@homnay", DateTime.Today);
            int soDong = cmd.ExecuteNonQuery();          // số sản phẩm vừa được tạo tồn kho
            if (soDong > 0) MessageBox.Show("Đã tạo tồn kho ngày " + DateTime.Today.ToString("dd/MM/yyyy") + " cho " + soDong + " sản phẩm.");
            else MessageBox.Show("Không có sản phẩm nào cần tạo thêm (tồn kho hôm nay đã được tạo rồi).");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
