using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài tập nâng cao 2: Danh sách điểm của sinh viên theo môn học (ListView + Tổng điểm)
public class frmDanhSachDiem : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    ComboBox cboMonHoc; ListView lvDiem; TextBox txtTongDiem;

    public frmDanhSachDiem()
    {
        UI.Setup(this, "Danh sách sinh viên", 680, 450);
        UI.Lbl(this, "Môn học", 15, 17, 70);   cboMonHoc = UI.Cbo(this, 90, 15, 260);
        UI.Btn(this, "Lọc dữ liệu", 370, 12, 110, 32, btnLoc_Click);
        lvDiem = UI.LV(this, 15, 60, 650, 330,
                       ("STT", 50), ("Tên SV", 190), ("Ngày sinh", 110), ("Tên môn học", 180), ("Điểm", 80));
        UI.Lbl(this, "Tổng điểm", 400, 404, 80);
        txtTongDiem = UI.Txt(this, 485, 402, 120); txtTongDiem.ReadOnly = true;
        Load += frmDanhSachDiem_Load;
    }

    // Sự kiện Load: nạp mã môn học (+ 1 dòng trống = tất cả môn học) và hiển thị toàn bộ điểm
    private void frmDanhSachDiem_Load(object sender, EventArgs e)
    {
        try
        {
            KetNoi.NapComboBox(connsql, cboMonHoc, "SELECT MaMonHoc FROM MonHoc ORDER BY MaMonHoc", "MaMonHoc");
            cboMonHoc.Items.Insert(0, "");           // item khoảng trắng = tất cả môn học
            cboMonHoc.SelectedIndex = 0;
            HienThiDiem("");
        }
        catch (Exception ex) { UI.Warn("Không nạp được dữ liệu: " + ex.Message); }
    }

    private void btnLoc_Click(object sender, EventArgs e)
    {
        string maMH = "";
        if (cboMonHoc.SelectedItem != null) maMH = cboMonHoc.SelectedItem.ToString();
        HienThiDiem(maMH);
    }

    // maMonHoc = "" -> tất cả môn học; ngược lại chỉ lấy điểm của môn học đó
    private void HienThiDiem(string maMonHoc)
    {
        try
        {
            connsql.Open();
            string selectString =
                "SELECT sv.HoTen, sv.NgaySinh, mh.TenMonHoc, d.Diem " +
                "FROM Diem d " +
                "JOIN SinhVien sv ON sv.MaSinhVien = d.MaSinhVien " +
                "JOIN MonHoc mh ON mh.MaMonHoc = d.MaMonHoc ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connsql;
            if (maMonHoc != "")
            {
                selectString += "WHERE d.MaMonHoc = @mh ";
                cmd.Parameters.AddWithValue("@mh", maMonHoc);
            }
            selectString += "ORDER BY mh.MaMonHoc, sv.MaSinhVien";
            cmd.CommandText = selectString;

            SqlDataReader rd = cmd.ExecuteReader();
            lvDiem.Items.Clear();
            int stt = 0;
            double tong = 0;                             // tổng cột Điểm đang hiển thị
            while (rd.Read())
            {
                stt++;
                double diem = Convert.ToDouble(rd["Diem"]);
                tong += diem;
                ListViewItem item = new ListViewItem(stt.ToString());
                item.SubItems.Add(rd["HoTen"].ToString());
                item.SubItems.Add(Convert.ToDateTime(rd["NgaySinh"]).ToString("dd/MM/yyyy"));
                item.SubItems.Add(rd["TenMonHoc"].ToString());
                item.SubItems.Add(diem.ToString());
                lvDiem.Items.Add(item);
            }
            rd.Close();
            txtTongDiem.Text = tong.ToString();
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
