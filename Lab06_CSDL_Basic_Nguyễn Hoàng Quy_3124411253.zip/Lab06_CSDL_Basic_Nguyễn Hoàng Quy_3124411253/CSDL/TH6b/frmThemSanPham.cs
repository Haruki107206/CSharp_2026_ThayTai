using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài tập về nhà 1: Thêm sản phẩm mới
//   - Thêm 1 dòng vào SANPHAM (MaSP tự động tăng)
//   - Thêm 1 dòng vào TONKHO (hôm nay) với SLDau = 0, SLNhap = 0, SLBan = 0
public class frmThemSanPham : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLCuaHang);
    TextBox txtTenSP;

    public frmThemSanPham()
    {
        UI.Setup(this, "Thêm sản phẩm mới", 400, 150);
        UI.Lbl(this, "Tên sản phẩm", 20, 25, 100);  txtTenSP = UI.Txt(this, 125, 23, 250);
        UI.Btn(this, "Thêm", 125, 75, 100, 34, btnThem_Click);
        UI.Btn(this, "Thoát", 235, 75, 100, 34, (s, e) => Close());
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string ten = txtTenSP.Text.Trim();
        if (ten == "") { UI.Warn("Tên sản phẩm không được để trống!"); txtTenSP.Focus(); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            // 2 lệnh INSERT chạy trong 1 giao dịch (BEGIN TRAN ... COMMIT): hoặc cùng thành công, hoặc cùng bị hủy.
            // SCOPE_IDENTITY() = mã sản phẩm (tự động tăng) vừa được tạo ở lệnh INSERT trước đó.
            string sql =
                "SET XACT_ABORT ON; BEGIN TRAN; " +
                "INSERT INTO SANPHAM(TenSP) VALUES(@ten); " +
                "INSERT INTO TONKHO(MaSP, NgayTon, SLDau, SLNhap, SLBan) VALUES(SCOPE_IDENTITY(), @homnay, 0, 0, 0); " +
                "COMMIT TRAN;";
            SqlCommand cmd = new SqlCommand(sql, connsql);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@homnay", DateTime.Today);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
            txtTenSP.Clear(); txtTenSP.Focus();
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
