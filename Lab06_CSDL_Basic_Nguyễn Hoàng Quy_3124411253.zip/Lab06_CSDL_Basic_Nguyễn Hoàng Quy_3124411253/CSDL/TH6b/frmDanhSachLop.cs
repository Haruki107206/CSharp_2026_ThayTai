using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài tập nâng cao 1: Hiển thị danh sách Lớp trên ListView
public class frmDanhSachLop : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    ListView lvLop;

    public frmDanhSachLop()
    {
        UI.Setup(this, "Danh sách Lớp", 640, 420);
        UI.Btn(this, "Hiển thị dữ liệu", 15, 12, 140, 32, btnHienThi_Click);
        lvLop = UI.LV(this, 15, 55, 610, 300, ("STT", 60), ("Mã lớp", 130), ("Tên lớp", 270), ("Mã khoa", 120));
        UI.Btn(this, "Thoát", 525, 370, 100, 34, (s, e) => Close());
    }

    private void btnHienThi_Click(object sender, EventArgs e)
    {
        try
        {
            connsql.Open();
            SqlCommand cmd = new SqlCommand("SELECT MaLop, TenLop, MaKhoa FROM Lop ORDER BY MaLop", connsql);
            SqlDataReader rd = cmd.ExecuteReader();

            lvLop.Items.Clear();
            int stt = 0;                                   // số thứ tự tăng dần
            while (rd.Read())
            {
                stt++;
                ListViewItem item = new ListViewItem(stt.ToString());   // cột 1: STT
                item.SubItems.Add(rd["MaLop"].ToString());              // cột 2
                item.SubItems.Add(rd["TenLop"].ToString());             // cột 3
                item.SubItems.Add(rd["MaKhoa"].ToString());             // cột 4
                lvLop.Items.Add(item);
            }
            rd.Close();
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
