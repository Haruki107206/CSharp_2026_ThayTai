using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài mẫu 1: Quản lý Khoa + KIỂM TRA TRÙNG KHÓA CHÍNH bằng ExecuteScalar
public class frmKhoa : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaKhoa, txtTenKhoa;

    public frmKhoa()
    {
        UI.Setup(this, "Quản lý Khoa", 380, 160);
        UI.Lbl(this, "Mã khoa", 15, 15, 70);   txtMaKhoa = UI.Txt(this, 90, 13, 270);
        UI.Lbl(this, "Tên khoa", 15, 50, 70);  txtTenKhoa = UI.Txt(this, 90, 48, 270);
        UI.Btn(this, "Thêm", 25, 100, 100, 34, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 100, 100, 34, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 100, 100, 34, btnSua_Click);
    }

    // Trả về true nếu Mã khoa CHƯA tồn tại (thêm được); false nếu đã có (trùng khóa chính).
    // Dùng ExecuteScalar để lấy 1 giá trị: số dòng có mã khoa này.
    private bool KT_MaKhoa(string ma)
    {
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();          // mở kết nối
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Khoa WHERE MaKhoa=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            int count = (int)cmd.ExecuteScalar();                                 // thực thi truy vấn lấy 1 giá trị
            if (count >= 1) return false;
            return true;
        }
        finally
        {
            if (connsql.State == ConnectionState.Open) connsql.Close();           // đóng kết nối
        }
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim(), ten = txtTenKhoa.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã khoa và Tên khoa không được để trống!"); return; }
        try
        {
            if (KT_MaKhoa(ma) == true)
            {
                connsql.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Khoa(MaKhoa, TenKhoa) VALUES(@ma, @ten)", connsql);
                cmd.Parameters.AddWithValue("@ma", ma);
                cmd.Parameters.AddWithValue("@ten", ten);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thành công");
            }
            else { MessageBox.Show("Trùng mã khoa"); }
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnXoa_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim();
        if (ma == "") { UI.Warn("Mã khoa không được để trống!"); return; }
        try
        {
            // Kiểm tra khóa chính: khoa phải tồn tại
            if (KT_MaKhoa(ma) == true) { UI.Warn("Mã khoa không tồn tại!"); return; }
            // Kiểm tra khóa ngoại: nếu đã có lớp thuộc khoa này thì không được xóa
            if (KetNoi.CoDuLieu(connsql, "SELECT * FROM Lop WHERE MaKhoa=@ma", new SqlParameter("@ma", ma)))
            { UI.Warn("Khoa này đang có lớp, không thể xóa!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Khoa WHERE MaKhoa=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnSua_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim(), ten = txtTenKhoa.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã khoa và Tên khoa không được để trống!"); return; }
        try
        {
            if (KT_MaKhoa(ma) == true) { UI.Warn("Mã khoa không tồn tại!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Khoa SET TenKhoa=@ten WHERE MaKhoa=@ma", connsql);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@ma", ma);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
