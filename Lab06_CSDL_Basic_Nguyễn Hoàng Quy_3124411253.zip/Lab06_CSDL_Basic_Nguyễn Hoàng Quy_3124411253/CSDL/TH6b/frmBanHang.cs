using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài tập về nhà 1: Bán hàng
public class frmBanHang : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLCuaHang);
    Button btnTaoHoaDon, btnThem, btnHuy, btnThanhToan;
    GroupBox grpChiTiet;
    TextBox txtMaHD, txtSoLuong;
    ComboBox cboSanPham;
    ListView lvChiTiet;
    int maHD = 0;      // mã hóa đơn đang lập; 0 = chưa có hóa đơn nào

    public frmBanHang()
    {
        UI.Setup(this, "BanHang", 560, 480);

        btnTaoHoaDon = UI.Btn(this, "Tạo hóa đơn mới", 390, 12, 150, 32, btnTaoHoaDon_Click);

        grpChiTiet = UI.Grp(this, "Chi tiết hóa đơn", 20, 55, 520, 190);
        UI.Lbl(grpChiTiet, "Mã hóa đơn", 20, 32, 110);   txtMaHD = UI.Txt(grpChiTiet, 140, 30, 200); txtMaHD.ReadOnly = true;
        UI.Lbl(grpChiTiet, "Mã sản phẩm", 20, 70, 110);  cboSanPham = UI.Cbo(grpChiTiet, 140, 68, 200);
        UI.Lbl(grpChiTiet, "Số lượng", 20, 108, 110);    txtSoLuong = UI.Txt(grpChiTiet, 140, 106, 200);
        btnThem = UI.Btn(grpChiTiet, "Thêm", 140, 145, 95, 32, btnThem_Click);
        btnHuy = UI.Btn(grpChiTiet, "Hủy", 245, 145, 95, 32, btnHuy_Click);

        btnThanhToan = UI.Btn(this, "Thanh toán", 390, 255, 150, 32, btnThanhToan_Click);
        UI.Lbl(this, "Các sản phẩm đã thêm vào hóa đơn:", 20, 258, 300);
        lvChiTiet = UI.LV(this, 20, 295, 520, 170, ("Mã SP", 90), ("Tên sản phẩm", 300), ("Số lượng", 100));

        DatTrangThai(false);                 // ban đầu: các điều khiển bị mờ
        Load += frmBanHang_Load;
        FormClosing += (s, e) =>
        {
            if (maHD != 0 && e.CloseReason == CloseReason.UserClosing &&
                !UI.Ask("Hóa đơn " + maHD + " chưa thanh toán. Bạn vẫn muốn đóng form?"))
                e.Cancel = true;
        };
    }

    // dangLap = true : đang lập hóa đơn -> bật nhóm Chi tiết + nút Thanh toán, khóa nút Tạo hóa đơn mới
    // dangLap = false: không có hóa đơn   -> làm mờ lại và xóa trắng
    private void DatTrangThai(bool dangLap)
    {
        grpChiTiet.Enabled = dangLap;
        btnThanhToan.Enabled = dangLap;
        btnTaoHoaDon.Enabled = !dangLap;
        if (!dangLap)
        {
            maHD = 0;
            txtMaHD.Clear(); txtSoLuong.Clear();
            lvChiTiet.Items.Clear();
        }
    }

    // Hiển thị mã sản phẩm (khóa ngoại) trên ComboBox Sản phẩm
    private void frmBanHang_Load(object sender, EventArgs e)
    {
        try { KetNoi.NapComboBox(connsql, cboSanPham, "SELECT MaSP FROM SANPHAM ORDER BY MaSP", "MaSP"); }
        catch (Exception ex) { UI.Warn("Không nạp được danh sách sản phẩm: " + ex.Message); }
    }

    // Tạo hóa đơn mới: mã tự động tăng, ngày tạo = hiện tại, tình trạng = 0 (chưa thanh toán)
    private void btnTaoHoaDon_Click(object sender, EventArgs e)
    {
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            // SCOPE_IDENTITY() trả về mã hóa đơn vừa được tự động tạo
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO HOADON(NgayTao, TinhTrangThanhToan) VALUES(@ngay, 0); SELECT SCOPE_IDENTITY();", connsql);
            cmd.Parameters.AddWithValue("@ngay", DateTime.Now);
            maHD = Convert.ToInt32(cmd.ExecuteScalar());     // ExecuteScalar: lấy 1 giá trị (mã hóa đơn)
            txtMaHD.Text = maHD.ToString();
            lvChiTiet.Items.Clear();
            DatTrangThai(true);
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        // 1. Kiểm tra dữ liệu nhập
        if (cboSanPham.SelectedIndex < 0) { UI.Warn("Hãy chọn mã sản phẩm!"); return; }
        if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong) || soLuong <= 0)
        { UI.Warn("Số lượng phải là số nguyên lớn hơn 0!"); txtSoLuong.Focus(); return; }
        int maSP = int.Parse(cboSanPham.SelectedItem.ToString());

        try
        {
            // 2. Kiểm tra khóa ngoại: hóa đơn và sản phẩm phải tồn tại
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM HOADON WHERE MaHD=@hd", new SqlParameter("@hd", maHD)))
            { UI.Warn("Hóa đơn không tồn tại!"); return; }
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM SANPHAM WHERE MaSP=@sp", new SqlParameter("@sp", maSP)))
            { UI.Warn("Sản phẩm không tồn tại!"); return; }

            // 3. Kiểm tra khóa chính (MaHD, MaSP): sản phẩm chưa có trong hóa đơn này
            if (KetNoi.CoDuLieu(connsql, "SELECT * FROM CHITIET_HOADON WHERE MaHD=@hd AND MaSP=@sp",
                                new SqlParameter("@hd", maHD), new SqlParameter("@sp", maSP)))
            { UI.Warn("Sản phẩm này đã có trong hóa đơn (trùng khóa chính)!"); return; }

            // 4. Số lượng tồn hiện tại của HÔM NAY = SLDau + SLNhap - SLBan
            connsql.Open();
            SqlCommand cmdTon = new SqlCommand(
                "SELECT SLDau + SLNhap - SLBan FROM TONKHO WHERE MaSP=@sp AND NgayTon=@homnay", connsql);
            cmdTon.Parameters.AddWithValue("@sp", maSP);
            cmdTon.Parameters.AddWithValue("@homnay", DateTime.Today);
            object kq = cmdTon.ExecuteScalar();               // null nếu không có dòng nào
            if (kq == null)
            {
                UI.Warn("Chưa có dữ liệu tồn kho hôm nay cho sản phẩm này.\nHãy chọn menu \"Tạo tồn kho\" trước khi bán hàng.");
                return;
            }
            int ton = Convert.ToInt32(kq);
            if (soLuong > ton)
            {
                UI.Warn("Số lượng bán vượt quá số lượng tồn!\nSố lượng tồn hiện tại: " + ton);
                return;
            }

            // 5. Thêm chi tiết hóa đơn + cập nhật tổng SLBan trong TONKHO (cùng 1 giao dịch)
            string sql =
                "SET XACT_ABORT ON; BEGIN TRAN; " +
                "INSERT INTO CHITIET_HOADON(MaHD, MaSP, SoLuong) VALUES(@hd, @sp, @sl); " +
                "UPDATE TONKHO SET SLBan = SLBan + @sl WHERE MaSP=@sp AND NgayTon=@homnay; " +
                "COMMIT TRAN;";
            SqlCommand cmd = new SqlCommand(sql, connsql);
            cmd.Parameters.AddWithValue("@hd", maHD);
            cmd.Parameters.AddWithValue("@sp", maSP);
            cmd.Parameters.AddWithValue("@sl", soLuong);
            cmd.Parameters.AddWithValue("@homnay", DateTime.Today);
            cmd.ExecuteNonQuery();
            connsql.Close();

            txtSoLuong.Clear();
            HienThiChiTiet();
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Đọc lại chi tiết của hóa đơn đang lập (SqlDataReader) rồi hiển thị lên ListView
    private void HienThiChiTiet()
    {
        try
        {
            connsql.Open();
            SqlCommand cmd = new SqlCommand(
                "SELECT ct.MaSP, sp.TenSP, ct.SoLuong FROM CHITIET_HOADON ct " +
                "JOIN SANPHAM sp ON sp.MaSP = ct.MaSP WHERE ct.MaHD=@hd ORDER BY ct.MaSP", connsql);
            cmd.Parameters.AddWithValue("@hd", maHD);
            SqlDataReader rd = cmd.ExecuteReader();
            lvChiTiet.Items.Clear();
            while (rd.Read())
            {
                ListViewItem item = new ListViewItem(rd["MaSP"].ToString());
                item.SubItems.Add(rd["TenSP"].ToString());
                item.SubItems.Add(rd["SoLuong"].ToString());
                lvChiTiet.Items.Add(item);
            }
            rd.Close();
        }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Hủy hóa đơn đang lập: trả lại số lượng đã bán vào tồn kho, xóa chi tiết rồi xóa hóa đơn
    private void btnHuy_Click(object sender, EventArgs e)
    {
        if (!UI.Ask("Bạn có chắc muốn hủy hóa đơn " + maHD + "?")) return;
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            string sql =
                "SET XACT_ABORT ON; BEGIN TRAN; " +
                "UPDATE t SET t.SLBan = t.SLBan - ct.SoLuong " +
                "  FROM TONKHO t JOIN CHITIET_HOADON ct ON ct.MaSP = t.MaSP " +
                "  WHERE ct.MaHD=@hd AND t.NgayTon=@homnay; " +
                "DELETE FROM CHITIET_HOADON WHERE MaHD=@hd; " +
                "DELETE FROM HOADON WHERE MaHD=@hd; " +
                "COMMIT TRAN;";
            SqlCommand cmd = new SqlCommand(sql, connsql);
            cmd.Parameters.AddWithValue("@hd", maHD);
            cmd.Parameters.AddWithValue("@homnay", DateTime.Today);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Đã hủy hóa đơn");
            DatTrangThai(false);
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Thanh toán: đổi tình trạng hóa đơn từ 0 sang 1
    private void btnThanhToan_Click(object sender, EventArgs e)
    {
        if (lvChiTiet.Items.Count == 0) { UI.Warn("Hóa đơn chưa có sản phẩm nào!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE HOADON SET TinhTrangThanhToan = 1 WHERE MaHD=@hd", connsql);
            cmd.Parameters.AddWithValue("@hd", maHD);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Đã thanh toán hóa đơn " + maHD);
            DatTrangThai(false);
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
