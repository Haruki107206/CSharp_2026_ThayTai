using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6b;

// TH6b – Bài mẫu 2: Quản lý Lớp
//  - SqlDataReader nạp khóa ngoại (Mã khoa) vào ComboBox
//  - SqlDataReader kiểm tra khóa chính (trùng Mã lớp) trước khi Thêm
//  - SqlDataReader kiểm tra khóa ngoại trước khi Xóa / Sửa
public class frmLop : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    ComboBox cboKhoa; Label lblMaLop; TextBox txtMaLop, txtTenLop;

    public frmLop()
    {
        UI.Setup(this, "Quản lý Lớp", 380, 205);
        UI.Lbl(this, "Khoa", 15, 15, 70);     cboKhoa = UI.Cbo(this, 90, 13, 270);
        lblMaLop = UI.Lbl(this, "Mã lớp", 15, 50, 70);  txtMaLop = UI.Txt(this, 90, 48, 270);
        UI.Lbl(this, "Tên lớp", 15, 85, 70);  txtTenLop = UI.Txt(this, 90, 83, 270);
        UI.Btn(this, "Thêm", 25, 140, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 140, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 140, 100, 36, btnSua_Click);
        Load += frmLop_Load;
    }

    // Công việc 1: sự kiện Form Load gọi phương thức nạp ComboBox
    private void frmLop_Load(object sender, EventArgs e)
    {
        try { LoadKhoa_ComboBox(); }
        catch (Exception ex) { UI.Warn("Không nạp được danh sách khoa: " + ex.Message); }
    }

    // Dùng SqlDataReader đọc từng dòng bảng Khoa rồi thêm MaKhoa vào ComboBox
    private void LoadKhoa_ComboBox()
    {
        try
        {
            connsql.Open();                                           // mở kết nối CSDL
            string selectString = "SELECT * FROM Khoa";               // chuỗi truy vấn dạng hiển thị dữ liệu
            SqlCommand cmd = new SqlCommand(selectString, connsql);   // xây dựng command
            SqlDataReader rd = cmd.ExecuteReader();                   // truy vấn dạng hiển thị dữ liệu
            cboKhoa.Items.Clear();
            while (rd.Read())                                         // đọc từng dòng kết quả
            {
                cboKhoa.Items.Add(rd["MaKhoa"].ToString());
            }
            rd.Close();
            if (cboKhoa.Items.Count > 0) cboKhoa.SelectedIndex = 0;
        }
        finally
        {
            if (connsql.State == ConnectionState.Open) connsql.Close();   // đóng kết nối
        }
    }

    // Công việc 2: kiểm tra khóa chính của bảng Lop bằng SqlDataReader.
    // Trả về true khi Mã lớp CHƯA tồn tại (thêm được); false khi đã tồn tại (trùng khóa chính).
    public bool KT_KhoaChinh(string pMa)
    {
        try
        {
            connsql.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Lop WHERE MaLop=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", pMa);
            SqlDataReader rd = cmd.ExecuteReader();
            bool khongTrung;
            if (rd.HasRows) khongTrung = false;      // có dòng -> mã đã tồn tại
            else khongTrung = true;
            rd.Close();
            return khongTrung;
        }
        finally
        {
            if (connsql.State == ConnectionState.Open) connsql.Close();
        }
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        // Ràng buộc giao diện: không cho rỗng
        if (txtMaLop.Text.Trim() == string.Empty)
        {
            MessageBox.Show("Bạn phải nhập " + lblMaLop.Text);
            txtMaLop.Focus();
            return;
        }
        if (cboKhoa.SelectedIndex < 0) { UI.Warn("Hãy chọn khoa!"); return; }
        if (txtTenLop.Text.Trim() == "") { UI.Warn("Bạn phải nhập Tên lớp"); txtTenLop.Focus(); return; }

        string maLop = txtMaLop.Text.Trim(), tenLop = txtTenLop.Text.Trim(), maKhoa = cboKhoa.SelectedItem.ToString();
        try
        {
            if (KT_KhoaChinh(maLop) == true)         // chưa trùng khóa chính mới được thêm
            {
                connsql.Open();
                // Ghi rõ tên cột: bảng Lop có thứ tự cột là MaLop, TenLop, MaKhoa
                SqlCommand cmd = new SqlCommand("INSERT INTO Lop(MaLop, TenLop, MaKhoa) VALUES(@ma, @ten, @khoa)", connsql);
                cmd.Parameters.AddWithValue("@ma", maLop);
                cmd.Parameters.AddWithValue("@ten", tenLop);
                cmd.Parameters.AddWithValue("@khoa", maKhoa);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thành công");
            }
            else
            {
                MessageBox.Show("Trùng mã lớp");
            }
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Công việc 3: Xóa – kiểm tra Mã lớp có tồn tại và có sinh viên nào đang tham chiếu (khóa ngoại) hay không
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string maLop = txtMaLop.Text.Trim();
        if (maLop == "") { MessageBox.Show("Bạn phải nhập " + lblMaLop.Text); txtMaLop.Focus(); return; }
        try
        {
            if (KT_KhoaChinh(maLop) == true) { UI.Warn("Mã lớp không tồn tại!"); return; }
            if (KetNoi.CoDuLieu(connsql, "SELECT * FROM SinhVien WHERE MaLop=@ma", new SqlParameter("@ma", maLop)))
            { UI.Warn("Lớp này đang có sinh viên, không thể xóa!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Lop WHERE MaLop=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", maLop);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Sửa – Tên lớp, Mã khoa thay đổi tương ứng Mã lớp. Kiểm tra: lớp phải tồn tại, khoa (khóa ngoại) phải tồn tại
    private void btnSua_Click(object sender, EventArgs e)
    {
        string maLop = txtMaLop.Text.Trim(), tenLop = txtTenLop.Text.Trim();
        if (maLop == "") { MessageBox.Show("Bạn phải nhập " + lblMaLop.Text); txtMaLop.Focus(); return; }
        if (cboKhoa.SelectedIndex < 0) { UI.Warn("Hãy chọn khoa!"); return; }
        if (tenLop == "") { UI.Warn("Bạn phải nhập Tên lớp"); txtTenLop.Focus(); return; }
        string maKhoa = cboKhoa.SelectedItem.ToString();
        try
        {
            if (KT_KhoaChinh(maLop) == true) { UI.Warn("Mã lớp không tồn tại!"); return; }
            if (!KetNoi.CoDuLieu(connsql, "SELECT * FROM Khoa WHERE MaKhoa=@khoa", new SqlParameter("@khoa", maKhoa)))
            { UI.Warn("Mã khoa không tồn tại!"); return; }

            connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Lop SET TenLop=@ten, MaKhoa=@khoa WHERE MaLop=@ma", connsql);
            cmd.Parameters.AddWithValue("@ten", tenLop);
            cmd.Parameters.AddWithValue("@khoa", maKhoa);
            cmd.Parameters.AddWithValue("@ma", maLop);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
