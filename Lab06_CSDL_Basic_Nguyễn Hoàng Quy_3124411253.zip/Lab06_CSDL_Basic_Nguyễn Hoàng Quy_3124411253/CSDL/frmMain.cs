namespace CSDL;

/// <summary>Form chính (MDI) chứa menu mở tất cả các bài của TH6a và TH6b.</summary>
public class frmMain : Form
{
    public frmMain()
    {
        UI.Setup(this, "Lab 06 – Lập trình tương tác CSDL", 1100, 720);
        IsMdiContainer = true;
        WindowState = FormWindowState.Maximized;

        var ms = new MenuStrip(); MainMenuStrip = ms; Controls.Add(ms);

        var m6a = new ToolStripMenuItem("TH6a");
        Add(m6a, "Quản lý Khoa", Open<TH6a.frmKhoa>);
        Add(m6a, "Quản lý Môn học", Open<TH6a.frmMonHoc>);
        Add(m6a, "Quản lý Sinh viên", Open<TH6a.frmSinhVien>);
        Add(m6a, "Quản lý Điểm", Open<TH6a.frmDiem>);
        Add(m6a, "Quản lý Lớp", Open<TH6a.frmLop>);

        var m6b = new ToolStripMenuItem("TH6b");
        Add(m6b, "Khoa (kiểm tra trùng khóa chính)", Open<TH6b.frmKhoa>);
        Add(m6b, "Lớp (ComboBox Khoa)", Open<TH6b.frmLop>);
        Add(m6b, "Sinh viên (ComboBox Lớp)", Open<TH6b.frmSinhVien_Combo>);
        Add(m6b, "Điểm (ComboBox SV, Môn học)", Open<TH6b.frmDiem_Combo>);
        Add(m6b, "Danh sách Lớp (ListView)", Open<TH6b.frmDanhSachLop>);
        Add(m6b, "Danh sách Điểm (ListView)", Open<TH6b.frmDanhSachDiem>);
        Add(m6b, "Quản lý cửa hàng (QLCuaHang)", () => new TH6b.frmCuaHang().Show(this));

        var mCuaSo = new ToolStripMenuItem("&Cửa sổ");
        ms.MdiWindowListItem = mCuaSo;
        var mThoat = new ToolStripMenuItem("&Thoát");
        mThoat.Click += (s, e) => Close();

        ms.Items.AddRange(new ToolStripItem[] { m6a, m6b, mCuaSo, mThoat });
    }

    static void Add(ToolStripMenuItem parent, string text, Action act) =>
        parent.DropDownItems.Add(text, null, (s, e) => act());

    // Mở form con (nếu đã mở thì chỉ kích hoạt lại)
    void Open<T>() where T : Form, new()
    {
        var f = MdiChildren.OfType<T>().FirstOrDefault();
        if (f != null) { f.Activate(); return; }
        f = new T { MdiParent = this, StartPosition = FormStartPosition.WindowsDefaultLocation };
        f.Show();
    }
}
