namespace CSDL;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Tự tạo 2 CSDL mẫu (QLSinhVien, QLCuaHang) nếu máy chưa có. Xem SQL\*.sql
        try
        {
            KetNoi.TaoCSDL("QLSinhVien.sql");
            KetNoi.TaoCSDL("QLCuaHang.sql");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Không kết nối/tạo được CSDL.\n" +
                            "Hãy kiểm tra SQL Server đã chạy chưa và sửa KetNoi.SERVER cho đúng tên server của bạn.\n\n" +
                            ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        Application.Run(new frmMain());
    }
}
