using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6a;

// TH6a – Bài tập về nhà 1: Quản lý Lớp (Mã khoa nhập bằng TextBox)
public class frmLop : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaKhoa, txtMaLop, txtTenLop;

    public frmLop()
    {
        UI.Setup(this, "frmLop", 380, 195);
        UI.Lbl(this, "Mã khoa", 15, 15, 70);  txtMaKhoa = UI.Txt(this, 90, 13, 270);
        UI.Lbl(this, "Mã lớp", 15, 50, 70);   txtMaLop = UI.Txt(this, 90, 48, 270);
        UI.Lbl(this, "Tên lớp", 15, 85, 70);  txtTenLop = UI.Txt(this, 90, 83, 270);
        UI.Btn(this, "Thêm", 25, 135, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 135, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 135, 100, 36, btnSua_Click);
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string khoa = txtMaKhoa.Text.Trim(), ma = txtMaLop.Text.Trim(), ten = txtTenLop.Text.Trim();
        if (khoa == "" || ma == "" || ten == "") { UI.Warn("Mã khoa, Mã lớp, Tên lớp không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            // Ghi rõ tên cột để không bị nhầm thứ tự cột (bảng Lop: MaLop, TenLop, MaKhoa)
            SqlCommand cmd = new SqlCommand("INSERT INTO Lop(MaLop, TenLop, MaKhoa) VALUES(@ma, @ten, @khoa)", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@khoa", khoa);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa: chỉ cần Mã lớp
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string ma = txtMaLop.Text.Trim();
        if (ma == "") { UI.Warn("Mã lớp không được để trống!"); txtMaLop.Focus(); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Lop WHERE MaLop=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy lớp có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Sửa: Mã lớp bắt buộc; Mã khoa, Tên lớp phải có ít nhất 1 ô có dữ liệu (ô nào trống thì giữ nguyên)
    private void btnSua_Click(object sender, EventArgs e)
    {
        string khoa = txtMaKhoa.Text.Trim(), ma = txtMaLop.Text.Trim(), ten = txtTenLop.Text.Trim();
        if (ma == "") { UI.Warn("Mã lớp không được để trống!"); txtMaLop.Focus(); return; }
        if (khoa == "" && ten == "") { UI.Warn("Mã khoa, Tên lớp phải có ít nhất một trường có dữ liệu!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connsql;
            string capNhat = "";
            if (khoa != "") { capNhat += "MaKhoa=@khoa, "; cmd.Parameters.AddWithValue("@khoa", khoa); }
            if (ten != "") { capNhat += "TenLop=@ten, "; cmd.Parameters.AddWithValue("@ten", ten); }
            capNhat = capNhat.TrimEnd(',', ' ');
            cmd.CommandText = "UPDATE Lop SET " + capNhat + " WHERE MaLop=@ma";
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy lớp có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
