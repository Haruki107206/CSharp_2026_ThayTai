using System.Data;
using System.Data.SqlClient;
using System.Globalization;
namespace CSDL.TH6a;

// TH6a – Bài tập nâng cao 1: Quản lý Sinh viên
public class frmSinhVien : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaLop, txtMaSV, txtHoTen;
    MaskedTextBox mtbNgaySinh;     // ô nhập có khuôn __/__/____

    public frmSinhVien()
    {
        UI.Setup(this, "Quản lý sinh viên", 380, 230);
        UI.Lbl(this, "Mã lớp", 15, 15, 75);     txtMaLop = UI.Txt(this, 95, 13, 265);
        UI.Lbl(this, "Mã sv", 15, 50, 75);      txtMaSV = UI.Txt(this, 95, 48, 265);
        UI.Lbl(this, "Họ tên", 15, 85, 75);     txtHoTen = UI.Txt(this, 95, 83, 265);
        UI.Lbl(this, "Ngày sinh", 15, 120, 75); mtbNgaySinh = UI.Mask(this, 95, 118, 265);
        UI.Btn(this, "Thêm", 25, 170, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 170, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 170, 100, 36, btnSua_Click);
    }

    // Đọc ngày sinh từ MaskedTextBox. Trả về: 0 = để trống, 1 = hợp lệ, -1 = nhập dở / sai
    private int DocNgaySinh(out DateTime ngay)
    {
        ngay = DateTime.MinValue;
        if (mtbNgaySinh.Text.Replace("/", "").Trim() == "") return 0;
        if (!mtbNgaySinh.MaskCompleted) return -1;
        bool ok = DateTime.TryParseExact(mtbNgaySinh.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out ngay);
        return ok ? 1 : -1;
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string maLop = txtMaLop.Text.Trim(), maSV = txtMaSV.Text.Trim(), hoTen = txtHoTen.Text.Trim();
        int kq = DocNgaySinh(out DateTime ngaySinh);
        if (maLop == "" || maSV == "" || hoTen == "" || kq == 0)
        { UI.Warn("Mã lớp, Mã sinh viên, Tên sinh viên, Ngày sinh không được để trống!"); return; }
        if (kq < 0) { UI.Warn("Ngày sinh không hợp lệ! (định dạng dd/MM/yyyy)"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO SinhVien(MaSinhVien, HoTen, NgaySinh, MaLop) VALUES(@ma, @ten, @ns, @lop)", connsql);
            cmd.Parameters.AddWithValue("@ma", maSV);
            cmd.Parameters.AddWithValue("@ten", hoTen);
            cmd.Parameters.AddWithValue("@ns", ngaySinh);
            cmd.Parameters.AddWithValue("@lop", maLop);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa: sinh viên có Mã sinh viên VÀ Tên trùng với thông tin vừa nhập
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string maSV = txtMaSV.Text.Trim(), hoTen = txtHoTen.Text.Trim();
        if (maSV == "" || hoTen == "") { UI.Warn("Mã sinh viên và Tên sinh viên không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM SinhVien WHERE MaSinhVien=@ma AND HoTen=@ten", connsql);
            cmd.Parameters.AddWithValue("@ma", maSV);
            cmd.Parameters.AddWithValue("@ten", hoTen);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy sinh viên có mã và tên này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Sửa: ô nào có nhập dữ liệu thì cập nhật, ô nào để trống thì giữ nguyên
    private void btnSua_Click(object sender, EventArgs e)
    {
        string maLop = txtMaLop.Text.Trim(), maSV = txtMaSV.Text.Trim(), hoTen = txtHoTen.Text.Trim();
        int kq = DocNgaySinh(out DateTime ngaySinh);
        if (maSV == "") { UI.Warn("Mã sinh viên không được để trống!"); return; }
        if (kq < 0) { UI.Warn("Ngày sinh không hợp lệ! (định dạng dd/MM/yyyy)"); return; }
        if (maLop == "" && hoTen == "" && kq == 0)
        { UI.Warn("Mã lớp, Tên sinh viên, Ngày sinh phải có ít nhất một trường có dữ liệu!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connsql;
            string capNhat = "";                       // ghép dần các cột cần sửa
            if (maLop != "") { capNhat += "MaLop=@lop, "; cmd.Parameters.AddWithValue("@lop", maLop); }
            if (hoTen != "") { capNhat += "HoTen=@ten, "; cmd.Parameters.AddWithValue("@ten", hoTen); }
            if (kq == 1) { capNhat += "NgaySinh=@ns, "; cmd.Parameters.AddWithValue("@ns", ngaySinh); }
            capNhat = capNhat.TrimEnd(',', ' ');       // bỏ dấu ", " thừa ở cuối
            cmd.CommandText = "UPDATE SinhVien SET " + capNhat + " WHERE MaSinhVien=@ma";
            cmd.Parameters.AddWithValue("@ma", maSV);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy sinh viên có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
