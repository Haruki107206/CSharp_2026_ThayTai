using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6a;

// TH6a – Bài tập tại lớp 1: Quản lý Môn học
public class frmMonHoc : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaMH, txtTenMH;

    public frmMonHoc()
    {
        UI.Setup(this, "Quản lý môn học", 380, 160);
        UI.Lbl(this, "Mã mh", 15, 15, 70);   txtMaMH = UI.Txt(this, 90, 13, 270);
        UI.Lbl(this, "Tên mh", 15, 50, 70);  txtTenMH = UI.Txt(this, 90, 48, 270);
        UI.Btn(this, "Thêm", 25, 100, 100, 34, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 100, 100, 34, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 100, 100, 34, btnSua_Click);
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string ma = txtMaMH.Text.Trim(), ten = txtTenMH.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã môn học và Tên môn học không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO MonHoc(MaMonHoc, TenMonHoc) VALUES(@ma, @ten)", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa: chỉ cần Mã môn học (Tên môn học không cần nhập)
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string ma = txtMaMH.Text.Trim();
        if (ma == "") { UI.Warn("Mã môn học không được để trống!"); txtMaMH.Focus(); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM MonHoc WHERE MaMonHoc=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy môn học có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnSua_Click(object sender, EventArgs e)
    {
        string ma = txtMaMH.Text.Trim(), ten = txtTenMH.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã môn học và Tên môn học không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE MonHoc SET TenMonHoc=@ten WHERE MaMonHoc=@ma", connsql);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy môn học có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
