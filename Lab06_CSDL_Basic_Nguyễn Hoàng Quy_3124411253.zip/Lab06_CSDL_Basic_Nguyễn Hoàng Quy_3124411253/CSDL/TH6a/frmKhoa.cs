using System.Data;
using System.Data.SqlClient;
namespace CSDL.TH6a;

// TH6a – Bài mẫu: Quản lý Khoa (Thêm / Xóa / Sửa bằng SqlConnection + SqlCommand)
public class frmKhoa : Form
{
    // Bước 2 + 3: khai báo đối tượng kết nối và khởi tạo chuỗi kết nối (Windows Authentication)
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaKhoa, txtTenKhoa;

    public frmKhoa()
    {
        UI.Setup(this, "Quản lý Khoa", 380, 160);
        UI.Lbl(this, "Mã khoa", 15, 15, 70);   txtMaKhoa = UI.Txt(this, 90, 13, 270);
        UI.Lbl(this, "Tên khoa", 15, 50, 70);  txtTenKhoa = UI.Txt(this, 90, 48, 270);
        UI.Btn(this, "Thêm", 25, 100, 100, 34, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 100, 100, 34, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 100, 100, 34, btnSua_Click);
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim(), ten = txtTenKhoa.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã khoa và Tên khoa không được để trống!"); return; }
        try
        {
            // Kiểm tra kết nối trước khi mở
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            // Chuỗi truy vấn dùng tham số @ma, @ten (giải thích trong README)
            string insertString = "INSERT INTO Khoa(MaKhoa, TenKhoa) VALUES(@ma, @ten)";
            SqlCommand cmd = new SqlCommand(insertString, connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.ExecuteNonQuery();                  // gửi lệnh Insert xuống CSDL
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally
        {
            // Luôn đóng kết nối dù thành công hay lỗi
            if (connsql.State == ConnectionState.Open) connsql.Close();
        }
    }

    private void btnXoa_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim();
        if (ma == "") { UI.Warn("Mã khoa không được để trống!"); txtMaKhoa.Focus(); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Khoa WHERE MaKhoa=@ma", connsql);
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();     // ExecuteNonQuery trả về SỐ DÒNG bị ảnh hưởng
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy khoa có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnSua_Click(object sender, EventArgs e)
    {
        string ma = txtMaKhoa.Text.Trim(), ten = txtTenKhoa.Text.Trim();
        if (ma == "" || ten == "") { UI.Warn("Mã khoa và Tên khoa không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Khoa SET TenKhoa=@ten WHERE MaKhoa=@ma", connsql);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@ma", ma);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy khoa có mã này!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
