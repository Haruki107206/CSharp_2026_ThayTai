using System.Data;
using System.Data.SqlClient;
using System.Globalization;
namespace CSDL.TH6a;

// TH6a – Bài tập nâng cao 2: Quản lý Điểm
public class frmDiem : Form
{
    SqlConnection connsql = new SqlConnection(KetNoi.ChuoiQLSinhVien);
    TextBox txtMaSV, txtMaMH, txtDiem;

    public frmDiem()
    {
        UI.Setup(this, "Quản lý Điểm", 380, 195);
        UI.Lbl(this, "Mã sv", 15, 15, 70);   txtMaSV = UI.Txt(this, 90, 13, 270);
        UI.Lbl(this, "Mã mh", 15, 50, 70);   txtMaMH = UI.Txt(this, 90, 48, 270);
        UI.Lbl(this, "Điểm", 15, 85, 70);    txtDiem = UI.Txt(this, 90, 83, 270);
        UI.Btn(this, "Thêm", 25, 135, 100, 36, btnThem_Click);
        UI.Btn(this, "Xóa", 140, 135, 100, 36, btnXoa_Click);
        UI.Btn(this, "Sửa", 255, 135, 100, 36, btnSua_Click);
    }

    // Điểm phải nhập và chỉ được là số (chấp nhận cả dấu , và .)
    private bool DocDiem(out double diem)
    {
        diem = 0;
        if (txtDiem.Text.Trim() == "") { UI.Warn("Điểm không được để trống!"); txtDiem.Focus(); return false; }
        if (!double.TryParse(txtDiem.Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out diem))
        { UI.Warn("Điểm chỉ được nhập số!"); txtDiem.Focus(); return false; }
        if (diem < 0 || diem > 10)
        { UI.Warn("Điểm phải nằm trong khoảng từ 0 đến 10!"); txtDiem.Focus(); return false; }
        return true;
    }

    private void btnThem_Click(object sender, EventArgs e)
    {
        string maSV = txtMaSV.Text.Trim(), maMH = txtMaMH.Text.Trim();
        if (maSV == "" || maMH == "") { UI.Warn("Mã sinh viên, Mã môn học, Điểm không được để trống!"); return; }
        if (!DocDiem(out double diem)) return;
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Diem(MaSinhVien, MaMonHoc, Diem) VALUES(@sv, @mh, @d)", connsql);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            cmd.Parameters.AddWithValue("@d", diem);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thành công");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    // Xóa dòng có Mã sinh viên và Mã môn học tương ứng (Điểm không cần nhập)
    private void btnXoa_Click(object sender, EventArgs e)
    {
        string maSV = txtMaSV.Text.Trim(), maMH = txtMaMH.Text.Trim();
        if (maSV == "" || maMH == "") { UI.Warn("Mã sinh viên và Mã môn học không được để trống!"); return; }
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Diem WHERE MaSinhVien=@sv AND MaMonHoc=@mh", connsql);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy dòng điểm tương ứng!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }

    private void btnSua_Click(object sender, EventArgs e)
    {
        string maSV = txtMaSV.Text.Trim(), maMH = txtMaMH.Text.Trim();
        if (maSV == "" || maMH == "") { UI.Warn("Mã sinh viên và Mã môn học không được để trống!"); return; }
        if (!DocDiem(out double diem)) return;
        try
        {
            if (connsql.State == ConnectionState.Closed) connsql.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Diem SET Diem=@d WHERE MaSinhVien=@sv AND MaMonHoc=@mh", connsql);
            cmd.Parameters.AddWithValue("@d", diem);
            cmd.Parameters.AddWithValue("@sv", maSV);
            cmd.Parameters.AddWithValue("@mh", maMH);
            int soDong = cmd.ExecuteNonQuery();
            if (soDong > 0) MessageBox.Show("Thành công");
            else MessageBox.Show("Không tìm thấy dòng điểm tương ứng!");
        }
        catch (Exception ex) { MessageBox.Show("Thất bại: " + ex.Message); }
        finally { if (connsql.State == ConnectionState.Open) connsql.Close(); }
    }
}
